package de.varo.session;

import de.varo.VaroPlugin;
import de.varo.data.VaroPlayer;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;

/**
 * Verwaltet den Projekttag in der konfigurierten Zeitzone (Standard: Europe/Berlin).
 * Der Tageswechsel kann von Mitternacht abweichen (projekt.tageswechsel-stunde).
 */
public class DayManager {

    private final VaroPlugin plugin;
    private String letzterBekannterTag = "";

    public DayManager(VaroPlugin plugin) {
        this.plugin = plugin;
    }

    /** Aktuelles "Varo-Datum" - beruecksichtigt die Tageswechsel-Stunde. */
    public LocalDate heute() {
        ZonedDateTime jetzt = ZonedDateTime.now(plugin.settings().zone());
        int wechsel = plugin.settings().tageswechselStunde();
        LocalDateTime lokal = jetzt.toLocalDateTime();
        if (lokal.getHour() < wechsel) {
            return lokal.toLocalDate().minusDays(1);
        }
        return lokal.toLocalDate();
    }

    /** Tag 1 ist der Starttag des Projekts. */
    public long projektTag() {
        return ChronoUnit.DAYS.between(plugin.settings().startDatum(), heute()) + 1;
    }

    /** Sekunden bis zum naechsten Tageswechsel. */
    public long sekundenBisTageswechsel() {
        ZonedDateTime jetzt = ZonedDateTime.now(plugin.settings().zone());
        ZonedDateTime naechster = jetzt.truncatedTo(ChronoUnit.HOURS)
                .withHour(plugin.settings().tageswechselStunde())
                .withMinute(0).withSecond(0).withNano(0);
        if (!naechster.isAfter(jetzt)) naechster = naechster.plusDays(1);
        return ChronoUnit.SECONDS.between(jetzt, naechster);
    }

    /** Formatierte Uhrzeit des naechsten moeglichen Joins nach Tageswechsel. */
    public String naechsterTagText() {
        long s = sekundenBisTageswechsel();
        return de.varo.util.TimeUtil.humanDe(s);
    }

    /**
     * Wird sekuendlich aufgerufen. Erkennt den Tageswechsel und setzt die Join-Zaehler
     * aller Spieler zurueck.
     */
    public void tick() {
        String heute = heute().toString();
        if (letzterBekannterTag.isEmpty()) {
            letzterBekannterTag = heute;
            return;
        }
        if (!letzterBekannterTag.equals(heute)) {
            letzterBekannterTag = heute;
            neuerTag();
        }
    }

    private void neuerTag() {
        LocalDate heute = heute();
        LocalDate gestern = heute.minusDays(1);

        for (VaroPlayer vp : plugin.data().alle()) {
            pruefeInaktivitaet(vp, gestern);
            vp.tagPruefen(heute);
        }

        plugin.data().speichern();
        plugin.getLogger().info("Neuer Projekttag: Tag " + projektTag() + " - Joins zurueckgesetzt.");
        org.bukkit.Bukkit.broadcast(de.varo.util.Txt.c(plugin.messages().praefix()
                + "&eEin neuer Projekttag hat begonnen: &6Tag " + projektTag()
                + " &8- &7Joins zurueckgesetzt."));
    }

    /**
     * Wer an einem Tag gar nicht online war, bekommt einen Strike.
     * Greift erst ab dem konfigurierten Projekttag, damit der Starttag keine
     * Strikes verteilt.
     */
    private void pruefeInaktivitaet(VaroPlayer vp, LocalDate gestern) {
        if (!plugin.settings().inaktivitaetAktiv()) return;
        if (!plugin.settings().strikesAktiv()) return;
        if (!vp.lebt()) return;
        if (projektTag() < plugin.settings().inaktivitaetAbTag()) return;

        // Noch nie gespielt: Stichtag setzen, aber diesmal noch verschonen
        if (vp.letzterSpieltag() == null || vp.letzterSpieltag().isBlank()) {
            vp.letzterSpieltag(gestern.toString());
            return;
        }

        LocalDate zuletzt;
        try {
            zuletzt = LocalDate.parse(vp.letzterSpieltag());
        } catch (Exception e) {
            vp.letzterSpieltag(gestern.toString());
            return;
        }

        long verpasst = ChronoUnit.DAYS.between(zuletzt, gestern);
        if (verpasst < 1) return;

        String grund = plugin.messages().raw("strike-inaktiv", "tage", verpasst);
        plugin.strikes().strikeGeben(vp, grund, "System");

        // Stichtag nachziehen, damit derselbe Tag nicht doppelt zaehlt
        vp.letzterSpieltag(gestern.toString());
    }
}
