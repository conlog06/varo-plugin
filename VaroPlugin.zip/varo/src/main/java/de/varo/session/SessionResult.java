package de.varo.session;

import net.kyori.adventure.text.Component;

/** Ergebnis der Join-Pruefung. */
public record SessionResult(boolean erlaubt, Component grund) {

    public static SessionResult ok() {
        return new SessionResult(true, null);
    }

    public static SessionResult abgelehnt(Component grund) {
        return new SessionResult(false, grund);
    }
}
