package de.varo.session;

import de.varo.VaroPlugin;
import de.varo.util.TimeUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.entity.Player;

import java.time.LocalTime;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;
import java.util.HashSet;
import java.util.Set;

/**
 * Der Server ist nur innerhalb eines taeglichen Zeitfensters betretbar
 * (Standard: 06:00 bis 23:59 Europe/Berlin).
 */
public class OpeningHoursManager {

    private final VaroPlugin plugin;
    private final Set<Integer> gewarnt = new HashSet<>();
    private boolean warOffen = true;

    public OpeningHoursManager(VaroPlugin plugin) {
        this.plugin = plugin;
    }

    private LocalTime oeffnet() {
        return LocalTime.of(plugin.settings().oeffnetStunde(), plugin.settings().oeffnetMinute());
    }

    private LocalTime schliesst() {
        return LocalTime.of(plugin.settings().schliesstStunde(), plugin.settings().schliesstMinute());
    }

    public boolean offen() {
        if (!plugin.settings().oeffnungAktiv()) return true;

        LocalTime jetzt = ZonedDateTime.now(plugin.settings().zone()).toLocalTime();
        LocalTime auf = oeffnet();
        LocalTime zu = schliesst();

        if (auf.isBefore(zu) || auf.equals(zu)) {
            return !jetzt.isBefore(auf) && !jetzt.isAfter(zu);
        }
        // Fenster ueber Mitternacht (z.B. 20:00 - 03:00)
        return !jetzt.isBefore(auf) || !jetzt.isAfter(zu);
    }

    /** Sekunden bis zur Schliessung (0, wenn geschlossen). */
    public long sekundenBisSchluss() {
        if (!offen()) return 0;
        ZonedDateTime jetzt = ZonedDateTime.now(plugin.settings().zone());
        ZonedDateTime zu = jetzt.with(schliesst()).withSecond(59).withNano(0);
        if (zu.isBefore(jetzt)) zu = zu.plusDays(1);
        return ChronoUnit.SECONDS.between(jetzt, zu);
    }

    /** Sekunden bis zur naechsten Oeffnung. */
    public long sekundenBisOeffnung() {
        ZonedDateTime jetzt = ZonedDateTime.now(plugin.settings().zone());
        ZonedDateTime auf = jetzt.with(oeffnet()).withSecond(0).withNano(0);
        if (!auf.isAfter(jetzt)) auf = auf.plusDays(1);
        return ChronoUnit.SECONDS.between(jetzt, auf);
    }

    public Component kickGrund() {
        return plugin.messages().plain("server-geschlossen",
                "von", plugin.settings().oeffnetText(),
                "bis", plugin.settings().schliesstText(),
                "restzeit", TimeUtil.humanDe(sekundenBisOeffnung()));
    }

    /** Sekundentakt. */
    public void tick() {
        if (!plugin.settings().oeffnungAktiv()) return;

        boolean istOffen = offen();

        if (istOffen && !warOffen) {
            warOffen = true;
            gewarnt.clear();
            Bukkit.broadcast(plugin.messages().chat("server-geoeffnet"));
            if (plugin.settings().discordAktiv() && plugin.settings().discordBeiServerzeiten()) {
                plugin.discord().sende("🟢 Server geoeffnet (" + plugin.settings().oeffnetText() + " Uhr).");
            }
            return;
        }

        if (!istOffen) {
            if (warOffen) {
                warOffen = false;
                schliessen();
            }
            // Nachzuegler direkt wieder rauswerfen
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (!p.hasPermission("varo.bypass.oeffnungszeiten")) {
                    p.kick(kickGrund());
                }
            }
            return;
        }

        // Vorwarnungen
        long restMinuten = sekundenBisSchluss() / 60L;
        long restSekunden = sekundenBisSchluss();

        for (int minute : plugin.settings().schlussWarnungen()) {
            if (restMinuten == minute && restSekunden % 60 >= 55 && gewarnt.add(minute)) {
                Bukkit.broadcast(plugin.messages().chat("server-schliesst-warnung",
                        "restzeit", minute + " Minuten",
                        "bis", plugin.settings().schliesstText()));
                for (Player p : Bukkit.getOnlinePlayers()) {
                    p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_BELL, 1f, 1f);
                }
            }
        }
    }

    private void schliessen() {
        gewarnt.clear();
        plugin.getLogger().info("Server-Zeitfenster beendet - alle Spieler werden gekickt.");

        if (plugin.settings().discordAktiv() && plugin.settings().discordBeiServerzeiten()) {
            plugin.discord().sende("🔴 Server geschlossen (" + plugin.settings().schliesstText()
                    + " Uhr). Naechste Oeffnung: " + plugin.settings().oeffnetText() + " Uhr.");
        }

        Component grund = plugin.messages().plain("server-schliesst-kick",
                "von", plugin.settings().oeffnetText());

        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.hasPermission("varo.bypass.oeffnungszeiten")) continue;
            plugin.sessionManager().beendeSession(p, true);
            p.kick(grund);
        }
        plugin.data().speichern();
    }
}
