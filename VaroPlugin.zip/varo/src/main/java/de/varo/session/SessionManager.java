package de.varo.session;

import de.varo.VaroPlugin;
import de.varo.data.VaroPlayer;
import de.varo.util.TimeUtil;
import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import net.kyori.adventure.title.Title;
import net.kyori.adventure.text.Component;

import java.time.Duration;
import java.util.*;

/**
 * Kern des Varo-Systems: begrenzt Joins pro Tag und Spielzeit pro Session.
 * Alle Werte sind zur Laufzeit vom Admin aenderbar und wirken sofort.
 */
public class SessionManager {

    private final VaroPlugin plugin;

    /** Startzeitpunkt der laufenden Session in epoch millis. */
    private final Map<UUID, Long> sessionStart = new HashMap<>();
    /** Bereits gesendete Warnschwellen, damit jede Warnung nur einmal kommt. */
    private final Map<UUID, Set<Integer>> gewarnt = new HashMap<>();
    /** Spieler, deren Kick wegen aktivem Kampf-Tag aufgeschoben wurde. */
    private final Set<UUID> kickWartet = new HashSet<>();

    public SessionManager(VaroPlugin plugin) {
        this.plugin = plugin;
    }

    // ================= Join-Pruefung =================

    /** Wird im PlayerLoginEvent aufgerufen, bevor der Spieler die Welt betritt. */
    public SessionResult darfJoinen(UUID id, String name) {
        var s = plugin.settings();

        if (!s.laeuft()) {
            return SessionResult.ok(); // Projekt pausiert: keine Limits
        }

        VaroPlayer vp = plugin.data().get(id);
        if (vp == null) return SessionResult.ok();   // Erster Join, wird beim Join angelegt

        if (!vp.lebt()) {
            return SessionResult.abgelehnt(plugin.messages().plain("tot"));
        }

        vp.tagPruefen(plugin.dayManager().heute());

        if (vp.joinsHeute() >= s.joinsProTag()) {
            return SessionResult.abgelehnt(plugin.messages().plain("joins-aufgebraucht",
                    "maxjoins", s.joinsProTag(),
                    "naechster", plugin.dayManager().naechsterTagText()));
        }

        long abkling = s.abklingzeitMinuten() * 60_000L;
        if (abkling > 0 && vp.letztesSessionEnde() > 0) {
            long verstrichen = System.currentTimeMillis() - vp.letztesSessionEnde();
            if (verstrichen < abkling) {
                long restSek = (abkling - verstrichen) / 1000L;
                return SessionResult.abgelehnt(plugin.messages().plain("abklingzeit",
                        "restzeit", TimeUtil.humanDe(restSek)));
            }
        }

        return SessionResult.ok();
    }

    // ================= Session-Lebenszyklus =================

    public void starteSession(Player p) {
        VaroPlayer vp = plugin.data().getOrCreate(p);
        vp.tagPruefen(plugin.dayManager().heute());

        if (!plugin.settings().laeuft()) {
            p.sendMessage(plugin.messages().chat("projekt-pausiert"));
            return;
        }

        vp.joinsHeute(vp.joinsHeute() + 1);
        sessionStart.put(p.getUniqueId(), System.currentTimeMillis());
        gewarnt.put(p.getUniqueId(), new HashSet<>());
        kickWartet.remove(p.getUniqueId());

        p.sendMessage(plugin.messages().chat("session-start",
                "restzeit", TimeUtil.humanDe(plugin.settings().sessionSekunden()),
                "joins", vp.joinsHeute(),
                "maxjoins", plugin.settings().joinsProTag()));

        plugin.data().speichern();
    }

    public void beendeSession(Player p, boolean gekickt) {
        UUID id = p.getUniqueId();
        Long start = sessionStart.remove(id);
        gewarnt.remove(id);
        kickWartet.remove(id);

        VaroPlayer vp = plugin.data().get(id);
        if (vp == null) return;

        if (start != null) {
            long dauer = (System.currentTimeMillis() - start) / 1000L;
            vp.spielzeitSekunden(vp.spielzeitSekunden() + dauer);
        }
        vp.letztesSessionEnde(System.currentTimeMillis());
        plugin.data().speichern();
    }

    /** Verbleibende Sekunden der laufenden Session. -1 = keine Begrenzung aktiv. */
    public long restSekunden(Player p) {
        if (!plugin.settings().laeuft()) return -1;
        Long start = sessionStart.get(p.getUniqueId());
        if (start == null) return -1;
        long verstrichen = (System.currentTimeMillis() - start) / 1000L;
        return Math.max(0, plugin.settings().sessionSekunden() - verstrichen);
    }

    public String restzeitText(Player p) {
        long r = restSekunden(p);
        return r < 0 ? "∞" : TimeUtil.format(r);
    }

    public boolean hatLaufendeSession(Player p) {
        return sessionStart.containsKey(p.getUniqueId());
    }

    // ================= Sekundentakt =================

    public void tick() {
        if (!plugin.settings().laeuft()) return;

        List<Integer> schwellen = plugin.settings().warnungen();

        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.hasPermission("varo.bypass.session")) continue;

            long rest = restSekunden(p);
            if (rest < 0) continue;

            Set<Integer> bereits = gewarnt.computeIfAbsent(p.getUniqueId(), k -> new HashSet<>());

            if (rest > 0) {
                for (int schwelle : schwellen) {
                    if (rest == schwelle && bereits.add(schwelle)) {
                        p.sendMessage(plugin.messages().chat("session-warnung",
                                "restzeit", TimeUtil.humanDe(rest)));
                        p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1f, rest <= 5 ? 2f : 1f);
                    }
                }
                if (rest <= plugin.settings().titelAbSekunde()) {
                    p.showTitle(Title.title(
                            de.varo.util.Txt.c("&c" + rest),
                            de.varo.util.Txt.c("&7Session endet"),
                            Title.Times.times(Duration.ZERO, Duration.ofMillis(1100), Duration.ZERO)));
                }
                continue;
            }

            // rest == 0 -> Kick, ggf. verzoegert wegen Kampf
            if (plugin.settings().kickVerzoegern() && plugin.combatTag().imKampf(p)) {
                if (kickWartet.add(p.getUniqueId())) {
                    p.sendMessage(plugin.messages().chat("kick-verzoegert"));
                }
                continue;
            }
            kickAusSession(p);
        }
    }

    public void kickAusSession(Player p) {
        p.sendMessage(plugin.messages().chat("session-ende"));
        beendeSession(p, true);
        p.kick(plugin.messages().plain("session-kick",
                "naechster", plugin.dayManager().naechsterTagText()));
    }

    /** Wird vom CombatTagManager aufgerufen, wenn ein Kampf-Tag auslaeuft. */
    public void pruefeVerzoegerteKicks() {
        for (UUID id : new HashSet<>(kickWartet)) {
            Player p = Bukkit.getPlayer(id);
            if (p == null) { kickWartet.remove(id); continue; }
            if (!plugin.combatTag().imKampf(p)) {
                kickWartet.remove(id);
                kickAusSession(p);
            }
        }
    }

    /** Verlaengert oder verkuerzt alle laufenden Sessions sofort - z.B. nach /varo set dauer 90. */
    public void alleSessionsNeuBerechnen() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            gewarnt.computeIfAbsent(p.getUniqueId(), k -> new HashSet<>()).clear();
        }
    }

    public Component restzeitComponent(Player p) {
        return de.varo.util.Txt.c("&7Restzeit: &f" + restzeitText(p));
    }
}
