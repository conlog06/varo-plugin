package de.varo.command;

import de.varo.VaroPlugin;
import de.varo.data.VaroPlayer;
import de.varo.data.VaroTeam;
import de.varo.util.TimeUtil;
import de.varo.util.Txt;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

public class VaroCommand {

    private final VaroPlugin plugin;
    private final Set<UUID> resetBestaetigung = new HashSet<>();

    public VaroCommand(VaroPlugin plugin) {
        this.plugin = plugin;
    }

    private void msg(CommandSender s, String text) {
        s.sendMessage(Txt.c(plugin.messages().praefix() + text));
    }

    /** Einstiegspunkt fuer alle drei Befehle. */
    public void fuehreAus(CommandSender sender, String label, String[] args) {

        String name = label.toLowerCase();

        if (name.equals("rucksack")) {
            if (!(sender instanceof Player p)) { msg(sender, "&cNur als Spieler."); return; }
            plugin.container().oeffneRucksack(p);
            return;
        }
        if (name.equals("teamkiste")) {
            if (!(sender instanceof Player p)) { msg(sender, "&cNur als Spieler."); return; }
            plugin.container().oeffneTeamkiste(p);
            return;
        }

        if (args.length == 0) {
            hilfe(sender);
            return;
        }

        String sub = args[0].toLowerCase();

        // ---- Fuer alle ----
        if (sub.equals("info") || sub.equals("status")) {
            status(sender, args.length > 1 ? args[1] : null);
            return;
        }

        // ---- Ab hier Admin ----
        if (!sender.hasPermission("varo.admin")) {
            msg(sender, plugin.messages().raw("keine-rechte"));
            return;
        }

        switch (sub) {
            case "set" -> setWert(sender, args);
            case "pause" -> {
                plugin.settings().laeuft(false);
                Bukkit.broadcast(Txt.c(plugin.messages().praefix() + "&eDas Projekt wurde &cpausiert&e."));
            }
            case "fortsetzen", "start" -> {
                plugin.settings().laeuft(true);
                plugin.sessionManager().alleSessionsNeuBerechnen();
                Bukkit.broadcast(Txt.c(plugin.messages().praefix() + "&aDas Projekt laeuft wieder."));
            }
            case "team" -> teamBefehl(sender, args);
            case "strike" -> strike(sender, args);
            case "unstrike" -> unstrike(sender, args);
            case "kill" -> kill(sender, args);
            case "revive" -> revive(sender, args);
            case "joins" -> joinsSetzen(sender, args);
            case "tag" -> tagSetzen(sender, args);
            case "menu", "gui", "admin" -> {
                if (sender instanceof Player p) plugin.adminGui().oeffneHaupt(p);
                else msg(sender, "&cDas Menü geht nur als Spieler.");
            }
            case "herzen" -> herzenSetzen(sender, args);
            case "backup" -> backup(sender);
            case "reset" -> reset(sender);
            case "reload" -> {
                plugin.reloadConfig();
                plugin.messages().laden();
                msg(sender, "&aConfig und Nachrichten neu geladen.");
            }
            default -> hilfe(sender);
        }
    }

    // ================= Unterbefehle =================

    private void hilfe(CommandSender s) {
        s.sendMessage(Txt.c("&8&m                                        "));
        s.sendMessage(Txt.c(" &6&lVARO &7- Befehle"));
        s.sendMessage(Txt.c(" &e/varo info [spieler] &8- &7Status anzeigen"));
        if (s.hasPermission("varo.admin")) {
            s.sendMessage(Txt.c(" &6/varo menu &8- &7Admin-Setup als GUI &8(empfohlen)"));
        }
        s.sendMessage(Txt.c(" &e/rucksack &8- &7Rucksack oeffnen"));
        s.sendMessage(Txt.c(" &e/teamkiste &8- &7Teamkiste oeffnen"));
        if (s.hasPermission("varo.admin")) {
            s.sendMessage(Txt.c(" &c/varo set dauer|joins|pause <wert>"));
            s.sendMessage(Txt.c(" &c/varo pause &8| &c/varo fortsetzen"));
            s.sendMessage(Txt.c(" &c/varo team erstellen|loeschen|add|remove|liste"));
            s.sendMessage(Txt.c(" &c/varo strike <spieler> <grund>"));
            s.sendMessage(Txt.c(" &c/varo unstrike|revive|kill <spieler>"));
            s.sendMessage(Txt.c(" &c/varo joins <spieler> <n> &8- &7Joins korrigieren"));
            s.sendMessage(Txt.c(" &c/varo tag <n> &8- &7Projekttag setzen"));
            s.sendMessage(Txt.c(" &c/varo backup &8| &c/varo reset &8| &c/varo reload"));
        }
        s.sendMessage(Txt.c("&8&m                                        "));
    }

    private void status(CommandSender s, String zielName) {
        VaroPlayer vp;
        if (zielName != null) {
            vp = plugin.data().byName(zielName);
            if (vp == null) { msg(s, plugin.messages().raw("spieler-nicht-gefunden", "spieler", zielName)); return; }
        } else if (s instanceof Player p) {
            vp = plugin.data().getOrCreate(p);
        } else {
            msg(s, "&cBitte einen Spielernamen angeben.");
            return;
        }

        VaroTeam team = plugin.data().teamVon(vp);
        var cfg = plugin.settings();

        s.sendMessage(Txt.c("&8&m                                        "));
        s.sendMessage(Txt.c(" &6&l" + vp.name()));
        s.sendMessage(Txt.c(" &7Status: " + (vp.lebt() ? "&aam Leben" : "&causgeschieden &8(" + vp.todesgrund() + ")")));
        s.sendMessage(Txt.c(" &7Team: &f" + (team != null ? team.farbe() + team.anzeigename() : "&8-")));
        s.sendMessage(Txt.c(" &7Joins heute: &f" + vp.joinsHeute() + "&7/&f" + cfg.joinsProTag()));
        s.sendMessage(Txt.c(" &7Strikes: &f" + vp.strikes() + "&7/&f" + cfg.strikeMaximum()));
        s.sendMessage(Txt.c(" &7Herzen: &c" + de.varo.health.HealthManager.format(vp.maxHerzen()) + " ♥"));
        s.sendMessage(Txt.c(" &7Kills: &f" + vp.kills() + " &8| &7Tode: &f" + vp.tode()));
        s.sendMessage(Txt.c(" &7Spielzeit: &f" + TimeUtil.humanDe(vp.spielzeitSekunden())));
        s.sendMessage(Txt.c(" &8Server " + cfg.oeffnetText() + " - " + cfg.schliesstText() + " Uhr"));
        s.sendMessage(Txt.c(" &8Tag " + plugin.dayManager().projektTag()
                + " • Season " + cfg.season()
                + " • Sessiondauer " + cfg.sessionMinuten() + "min"));
        s.sendMessage(Txt.c("&8&m                                        "));
    }

    private void setWert(CommandSender s, String[] args) {
        if (args.length < 3) {
            msg(s, "&cVerwendung: /varo set <dauer|joins|pause> <wert>");
            return;
        }
        int wert;
        try {
            wert = Integer.parseInt(args[2]);
        } catch (NumberFormatException e) {
            msg(s, "&cKeine gueltige Zahl: &f" + args[2]);
            return;
        }

        switch (args[1].toLowerCase()) {
            case "dauer" -> {
                plugin.settings().sessionMinuten(wert);
                plugin.sessionManager().alleSessionsNeuBerechnen();
                Bukkit.broadcast(Txt.c(plugin.messages().praefix()
                        + "&eSessiondauer geaendert auf &f" + wert + " Minuten&e."));
            }
            case "joins" -> {
                plugin.settings().joinsProTag(wert);
                Bukkit.broadcast(Txt.c(plugin.messages().praefix()
                        + "&eJoins pro Tag geaendert auf &f" + wert + "&e."));
            }
            case "pause", "abklingzeit" -> {
                plugin.settings().abklingzeitMinuten(wert);
                Bukkit.broadcast(Txt.c(plugin.messages().praefix()
                        + "&ePause zwischen Sessions: &f" + wert + " Minuten&e."));
            }
            default -> msg(s, "&cUnbekannt. Moeglich: dauer, joins, pause");
        }
    }

    private void teamBefehl(CommandSender s, String[] args) {
        if (args.length < 2) {
            msg(s, "&cVerwendung: /varo team <erstellen|loeschen|add|remove|liste> ...");
            return;
        }

        switch (args[1].toLowerCase()) {
            case "erstellen" -> {
                if (args.length < 4) {
                    msg(s, "&cVerwendung: /varo team erstellen <id> <FARBE> [Anzeigename]");
                    return;
                }
                String id = args[2].toLowerCase();
                if (plugin.data().team(id) != null) { msg(s, "&cTeam existiert bereits."); return; }

                ChatColor farbe;
                try {
                    farbe = ChatColor.valueOf(args[3].toUpperCase());
                } catch (Exception e) {
                    msg(s, "&cUnbekannte Farbe. z.B. RED, BLUE, GREEN, GOLD, AQUA");
                    return;
                }
                String anzeige = args.length > 4
                        ? String.join(" ", Arrays.copyOfRange(args, 4, args.length)) : id;

                VaroTeam t = plugin.data().teamErstellen(id, anzeige);
                t.farbe(farbe);
                plugin.data().speichern();
                msg(s, "&aTeam &f" + id + " &aerstellt.");
            }
            case "loeschen" -> {
                if (args.length < 3) { msg(s, "&cVerwendung: /varo team loeschen <id>"); return; }
                msg(s, plugin.data().teamLoeschen(args[2]) ? "&aTeam geloescht." : "&cTeam nicht gefunden.");
                plugin.data().speichern();
            }
            case "add" -> {
                if (args.length < 4) { msg(s, "&cVerwendung: /varo team add <id> <spieler>"); return; }
                VaroTeam t = plugin.data().team(args[2]);
                if (t == null) { msg(s, "&cTeam nicht gefunden."); return; }

                VaroPlayer vp = spielerFinden(args[3]);
                if (vp == null) { msg(s, plugin.messages().raw("spieler-nicht-gefunden", "spieler", args[3])); return; }

                VaroTeam alt = plugin.data().teamVon(vp);
                if (alt != null) alt.mitglieder().remove(vp.uuid());

                t.mitglieder().add(vp.uuid());
                vp.team(t.id());
                plugin.data().speichern();
                msg(s, "&f" + vp.name() + " &aist jetzt in Team &f" + t.anzeigename() + "&a.");
            }
            case "remove" -> {
                if (args.length < 3) { msg(s, "&cVerwendung: /varo team remove <spieler>"); return; }
                VaroPlayer vp = spielerFinden(args[2]);
                if (vp == null) { msg(s, "&cSpieler nicht gefunden."); return; }
                VaroTeam t = plugin.data().teamVon(vp);
                if (t != null) t.mitglieder().remove(vp.uuid());
                vp.team(null);
                plugin.data().speichern();
                msg(s, "&aSpieler aus dem Team entfernt.");
            }
            case "liste" -> {
                if (plugin.data().teams().isEmpty()) { msg(s, "&7Noch keine Teams angelegt."); return; }
                for (VaroTeam t : plugin.data().teams()) {
                    String mitglieder = t.mitgliederListe().stream()
                            .map(u -> {
                                VaroPlayer vp = plugin.data().get(u);
                                return vp == null ? "?" : (vp.lebt() ? vp.name() : "&8" + vp.name() + "&7");
                            })
                            .collect(Collectors.joining("&7, &f"));
                    s.sendMessage(Txt.c(" " + t.farbe() + t.anzeigename() + " &8» &f" + mitglieder));
                }
            }
            default -> msg(s, "&cUnbekannter Team-Befehl.");
        }
    }

    private void strike(CommandSender s, String[] args) {
        if (args.length < 3) { msg(s, "&cVerwendung: /varo strike <spieler> <grund>"); return; }
        VaroPlayer vp = spielerFinden(args[1]);
        if (vp == null) { msg(s, plugin.messages().raw("spieler-nicht-gefunden", "spieler", args[1])); return; }
        String grund = String.join(" ", Arrays.copyOfRange(args, 2, args.length));
        plugin.strikes().strikeGeben(vp, grund, s.getName());
    }

    private void unstrike(CommandSender s, String[] args) {
        if (args.length < 2) { msg(s, "&cVerwendung: /varo unstrike <spieler>"); return; }
        VaroPlayer vp = spielerFinden(args[1]);
        if (vp == null) { msg(s, "&cSpieler nicht gefunden."); return; }
        msg(s, plugin.strikes().strikeEntfernen(vp)
                ? "&aStrike entfernt. Jetzt: &f" + vp.strikes()
                : "&cDer Spieler hat keine Strikes.");
    }

    private void kill(CommandSender s, String[] args) {
        if (args.length < 2) { msg(s, "&cVerwendung: /varo kill <spieler> [grund]"); return; }
        VaroPlayer vp = spielerFinden(args[1]);
        if (vp == null) { msg(s, "&cSpieler nicht gefunden."); return; }
        String grund = args.length > 2
                ? String.join(" ", Arrays.copyOfRange(args, 2, args.length))
                : "durch Admin ausgeschieden";
        plugin.deathManager().spielerAusscheiden(vp, grund);
    }

    private void revive(CommandSender s, String[] args) {
        if (args.length < 2) { msg(s, "&cVerwendung: /varo revive <spieler>"); return; }
        VaroPlayer vp = spielerFinden(args[1]);
        if (vp == null) { msg(s, "&cSpieler nicht gefunden."); return; }
        vp.lebt(true);
        vp.todesgrund("");
        vp.todesZeit(0);
        plugin.data().speichern();

        Player online = Bukkit.getPlayer(vp.uuid());
        if (online != null) online.setGameMode(org.bukkit.GameMode.SURVIVAL);

        Bukkit.broadcast(Txt.c(plugin.messages().praefix() + "&a" + vp.name() + " wurde wiederbelebt."));
    }

    private void joinsSetzen(CommandSender s, String[] args) {
        if (args.length < 3) { msg(s, "&cVerwendung: /varo joins <spieler> <anzahl>"); return; }
        VaroPlayer vp = spielerFinden(args[1]);
        if (vp == null) { msg(s, "&cSpieler nicht gefunden."); return; }
        try {
            int n = Integer.parseInt(args[2]);
            vp.joinsHeute(Math.max(0, n));
            vp.letzterTag(plugin.dayManager().heute().toString());
            plugin.data().speichern();
            msg(s, "&aJoins von &f" + vp.name() + " &aauf &f" + n + " &agesetzt.");
        } catch (NumberFormatException e) {
            msg(s, "&cKeine gueltige Zahl.");
        }
    }

    private void tagSetzen(CommandSender s, String[] args) {
        if (args.length < 2) {
            msg(s, "&7Aktueller Projekttag: &fTag " + plugin.dayManager().projektTag());
            return;
        }
        try {
            int tag = Integer.parseInt(args[1]);
            LocalDate neuesStart = plugin.dayManager().heute().minusDays(tag - 1L);
            plugin.settings().startDatum(neuesStart);
            msg(s, "&aProjekttag auf &fTag " + tag + " &agesetzt (Start: " + neuesStart + ").");
        } catch (NumberFormatException e) {
            msg(s, "&cKeine gueltige Zahl.");
        }
    }

    private void herzenSetzen(CommandSender s, String[] args) {
        if (args.length < 3) { msg(s, "&cVerwendung: /varo herzen <spieler> <anzahl>"); return; }
        VaroPlayer vp = spielerFinden(args[1]);
        if (vp == null) { msg(s, "&cSpieler nicht gefunden."); return; }
        try {
            double h = Double.parseDouble(args[2].replace(',', '.'));
            plugin.health().setzeHerzen(vp, h);
            msg(s, "&aHerzen von &f" + vp.name() + " &aauf &c"
                    + de.varo.health.HealthManager.format(vp.maxHerzen()) + " ♥ &agesetzt.");
        } catch (NumberFormatException e) {
            msg(s, "&cKeine gültige Zahl.");
        }
    }

    private void backup(CommandSender s) {
        msg(s, "&7Backup wird erstellt...");
        plugin.backup().weltenSpeichern();
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            var pfad = plugin.backup().erstelleBackup("manuell");
            Bukkit.getScheduler().runTask(plugin, () ->
                    msg(s, pfad != null
                            ? "&aBackup erstellt: &f" + pfad.getFileName()
                            : "&cBackup fehlgeschlagen - siehe Konsole."));
        });
    }

    private void reset(CommandSender s) {
        UUID id = (s instanceof Player p) ? p.getUniqueId() : new UUID(0, 0);

        if (!resetBestaetigung.contains(id)) {
            resetBestaetigung.add(id);
            msg(s, "&c&lACHTUNG: &7Die Welt wird gesichert, der Server gestoppt und");
            msg(s, "&7beim Neustart werden neue Welten erzeugt.");
            msg(s, "&7Zum Bestaetigen innerhalb von 15 Sekunden erneut &c/varo reset &7eingeben.");
            Bukkit.getScheduler().runTaskLater(plugin, () -> resetBestaetigung.remove(id), 300L);
            return;
        }
        resetBestaetigung.remove(id);
        plugin.deathManager().manuellerReset(s.getName());
    }

    private VaroPlayer spielerFinden(String name) {
        Player online = Bukkit.getPlayerExact(name);
        if (online != null) return plugin.data().getOrCreate(online);
        return plugin.data().byName(name);
    }

    // ================= Tab-Completion =================

    public List<String> vervollstaendige(CommandSender s, String label, String[] args) {
        if (!label.equalsIgnoreCase("varo")) return List.of();

        if (args.length == 0) {
            List<String> basis = new ArrayList<>(List.of("info"));
            if (s.hasPermission("varo.admin")) {
                basis.addAll(List.of("menu", "set", "pause", "fortsetzen", "team", "strike", "unstrike",
                        "kill", "revive", "joins", "tag", "herzen", "backup", "reset", "reload"));
            }
            return basis.stream().sorted().toList();
        }

        if (args.length == 1) {
            List<String> basis = new ArrayList<>(List.of("info"));
            if (s.hasPermission("varo.admin")) {
                basis.addAll(List.of("menu", "set", "pause", "fortsetzen", "team", "strike", "unstrike",
                        "kill", "revive", "joins", "tag", "herzen", "backup", "reset", "reload"));
            }
            return filtere(basis, args[0]);
        }

        if (args.length == 2) {
            return switch (args[0].toLowerCase()) {
                case "set" -> filtere(List.of("dauer", "joins", "pause"), args[1]);
                case "team" -> filtere(List.of("erstellen", "loeschen", "add", "remove", "liste"), args[1]);
                case "strike", "unstrike", "kill", "revive", "joins", "info", "herzen" ->
                        filtere(spielerNamen(), args[1]);
                default -> List.of();
            };
        }

        if (args.length == 3) {
            if (args[0].equalsIgnoreCase("team")) {
                if (args[1].equalsIgnoreCase("add")) {
                    return filtere(plugin.data().teams().stream().map(VaroTeam::id).toList(), args[2]);
                }
                if (args[1].equalsIgnoreCase("loeschen")) {
                    return filtere(plugin.data().teams().stream().map(VaroTeam::id).toList(), args[2]);
                }
                if (args[1].equalsIgnoreCase("remove")) {
                    return filtere(spielerNamen(), args[2]);
                }
            }
        }

        if (args.length == 4 && args[0].equalsIgnoreCase("team") && args[1].equalsIgnoreCase("add")) {
            return filtere(spielerNamen(), args[3]);
        }

        return List.of();
    }

    private List<String> spielerNamen() {
        return plugin.data().alle().stream().map(VaroPlayer::name).toList();
    }

    private List<String> filtere(List<String> quelle, String prefix) {
        String p = prefix.toLowerCase();
        return quelle.stream().filter(x -> x.toLowerCase().startsWith(p)).sorted().toList();
    }
}
