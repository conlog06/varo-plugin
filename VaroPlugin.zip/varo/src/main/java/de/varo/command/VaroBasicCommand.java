package de.varo.command;

import io.papermc.paper.command.brigadier.BasicCommand;
import io.papermc.paper.command.brigadier.CommandSourceStack;

import java.util.Collection;

/**
 * Adapter auf Papers BasicCommand-API.
 *
 * Paper-Plugins (paper-plugin.yml) koennen Befehle NICHT in der YAML deklarieren -
 * JavaPlugin#getCommand wirft dort eine UnsupportedOperationException. Registriert
 * wird stattdessen ueber JavaPlugin#registerCommand in onEnable().
 */
public class VaroBasicCommand implements BasicCommand {

    private final String label;
    private final VaroCommand handler;

    public VaroBasicCommand(String label, VaroCommand handler) {
        this.label = label;
        this.handler = handler;
    }

    @Override
    public void execute(CommandSourceStack quelle, String[] args) {
        handler.fuehreAus(quelle.getSender(), label, args);
    }

    @Override
    public Collection<String> suggest(CommandSourceStack quelle, String[] args) {
        return handler.vervollstaendige(quelle.getSender(), label, args);
    }
}
