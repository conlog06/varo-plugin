package de.varo.listener;

import de.varo.VaroPlugin;
import de.varo.storage.VaroHolder;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;

public class ContainerListener implements Listener {

    private final VaroPlugin plugin;

    public ContainerListener(VaroPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        Inventory inv = e.getInventory();
        InventoryHolder holder = inv.getHolder();
        if (!(holder instanceof VaroHolder vh)) return;

        switch (vh.typ()) {
            case RUCKSACK -> plugin.container().speichereRucksack(vh.besitzer(), inv);
            case TEAMKISTE -> plugin.container().speichereTeamkiste(vh.besitzer(), inv);
        }
    }
}
