package de.varo.listener;

import de.varo.VaroPlugin;
import de.varo.gui.GuiHolder;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;

public class GuiListener implements Listener {

    private final VaroPlugin plugin;

    public GuiListener(VaroPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        if (!(e.getInventory().getHolder() instanceof GuiHolder holder)) return;

        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() == null
                || !e.getClickedInventory().equals(e.getInventory())) return;

        if (!p.hasPermission("varo.admin")) {
            p.closeInventory();
            return;
        }

        plugin.adminGui().klick(p, holder.menue(), holder.kontext(), e.getSlot(), e.getClick());
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        if (e.getInventory().getHolder() instanceof GuiHolder) {
            e.setCancelled(true);
        }
    }
}
