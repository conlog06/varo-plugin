package de.varo.listener;

import de.varo.VaroPlugin;
import de.varo.data.VaroPlayer;
import de.varo.session.SessionResult;
import de.varo.util.Txt;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.*;

public class PlayerListener implements Listener {

    private final VaroPlugin plugin;

    public PlayerListener(VaroPlugin plugin) {
        this.plugin = plugin;
    }

    // ================= Login =================

    @EventHandler(priority = EventPriority.HIGH)
    public void onLogin(PlayerLoginEvent e) {
        Player p = e.getPlayer();

        if (plugin.deathManager().resetLaeuft()) {
            e.disallow(PlayerLoginEvent.Result.KICK_OTHER,
                    Txt.c("&cDer Server wird gerade zurueckgesetzt. Bitte spaeter erneut versuchen."));
            return;
        }

        // 1. Serverzeitfenster
        if (!plugin.oeffnungszeiten().offen() && !p.hasPermission("varo.bypass.oeffnungszeiten")) {
            e.disallow(PlayerLoginEvent.Result.KICK_OTHER, plugin.oeffnungszeiten().kickGrund());
            return;
        }

        if (p.hasPermission("varo.bypass.session")) return;

        // 2. Ausgeschieden?
        VaroPlayer vp = plugin.data().get(p.getUniqueId());
        if (vp != null && !vp.lebt()) {
            e.disallow(PlayerLoginEvent.Result.KICK_OTHER, plugin.messages().plain("tot"));
            return;
        }

        // 3. Joins und Abklingzeit
        SessionResult ergebnis = plugin.sessionManager().darfJoinen(p.getUniqueId(), p.getName());
        if (!ergebnis.erlaubt()) {
            e.disallow(PlayerLoginEvent.Result.KICK_OTHER, ergebnis.grund());
        }
    }

    // ================= Join =================

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        VaroPlayer vp = plugin.data().getOrCreate(p);

        plugin.offlineEntities().entferne(p);

        // Anwesenheit fuer die Inaktivitaetsregel vermerken
        vp.letzterSpieltag(plugin.dayManager().heute().toString());

        plugin.health().anwenden(p);

        if (!vp.lebt()) {
            p.setGameMode(GameMode.SPECTATOR);
        } else if (!p.hasPermission("varo.bypass.session")) {
            plugin.sessionManager().starteSession(p);
        }

        plugin.display().einrichten(p);
        plugin.data().speichern();

        if (plugin.settings().discordAktiv() && plugin.settings().discordBeiJoinQuit()) {
            plugin.discord().sende("➡ **" + p.getName() + "** ist gejoint ("
                    + vp.joinsHeute() + "/" + plugin.settings().joinsProTag() + ")");
        }
    }

    // ================= Quit =================

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        Player p = e.getPlayer();
        VaroPlayer vp = plugin.data().getOrCreate(p);

        boolean imKampf = plugin.combatTag().imKampf(p);
        plugin.combatTag().entferne(p);
        plugin.sessionManager().beendeSession(p, false);

        if (imKampf && plugin.settings().kampfLogoutToetet() && vp.lebt()
                && !p.hasPermission("varo.bypass.kampftag")) {
            Bukkit.broadcast(plugin.messages().chat("kampf-tag-logout", "spieler", p.getName()));
            plugin.deathManager().todVerarbeiten(vp, "Combat-Log");
            return;
        }

        if (vp.lebt() && !plugin.deathManager().resetLaeuft()) {
            plugin.offlineEntities().spawn(p);
        }

        if (plugin.settings().discordAktiv() && plugin.settings().discordBeiJoinQuit()) {
            plugin.discord().sende("⬅ **" + p.getName() + "** hat den Server verlassen");
        }
    }

    // ================= Tod =================

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDeath(PlayerDeathEvent e) {
        Player p = e.getEntity();
        VaroPlayer vp = plugin.data().getOrCreate(p);
        if (!vp.lebt()) return;

        String grund = ermittleGrund(p);

        Player killer = p.getKiller();
        if (killer != null && !killer.getUniqueId().equals(p.getUniqueId())) {
            VaroPlayer vk = plugin.data().getOrCreate(killer);
            vk.kills(vk.kills() + 1);
            grund = "getoetet von " + killer.getName();
        }

        plugin.deathManager().todVerarbeiten(vp, grund);
    }

    private String ermittleGrund(Player p) {
        var last = p.getLastDamageCause();
        if (last == null) return "unbekannt";
        return switch (last.getCause()) {
            case FALL -> "Sturz";
            case FIRE, FIRE_TICK -> "Feuer";
            case LAVA -> "Lava";
            case DROWNING -> "Ertrunken";
            case ENTITY_EXPLOSION, BLOCK_EXPLOSION -> "Explosion";
            case VOID -> "Void";
            case STARVATION -> "Verhungert";
            case ENTITY_ATTACK -> "Mob";
            case SUFFOCATION -> "Erstickt";
            case FREEZE -> "Erfroren";
            default -> last.getCause().name().toLowerCase();
        };
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        Player p = e.getPlayer();
        Bukkit.getScheduler().runTask(plugin, () -> {
            VaroPlayer vp = plugin.data().get(p.getUniqueId());
            if (vp == null) return;
            if (!vp.lebt()) {
                p.setGameMode(GameMode.SPECTATOR);
            } else {
                plugin.health().anwenden(p);
                p.setHealth(Math.max(1.0, vp.maxHerzen() * 2.0));
            }
        });
    }
}
