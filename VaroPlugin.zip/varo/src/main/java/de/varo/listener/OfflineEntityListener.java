package de.varo.listener;

import de.varo.VaroPlugin;
import de.varo.data.VaroPlayer;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.EntityTargetEvent;
import org.bukkit.event.entity.EntityTransformEvent;
import org.bukkit.inventory.ItemStack;

import java.util.UUID;

public class OfflineEntityListener implements Listener {

    private final VaroPlugin plugin;

    public OfflineEntityListener(VaroPlugin plugin) {
        this.plugin = plugin;
    }

    /** Offline-Entities sollen keine anderen Mobs angreifen und nicht selbst Ziel von Mobs sein. */
    @EventHandler
    public void onTarget(EntityTargetEvent e) {
        if (plugin.offlineEntities().istOfflineEntity(e.getEntity())) {
            e.setCancelled(true);
            return;
        }
        if (e.getTarget() != null && plugin.offlineEntities().istOfflineEntity(e.getTarget())) {
            e.setCancelled(true);
        }
    }

    /** Kein Umwandeln (Zombie -> Ertrunkener usw.). */
    @EventHandler
    public void onTransform(EntityTransformEvent e) {
        if (plugin.offlineEntities().istOfflineEntity(e.getEntity())) {
            e.setCancelled(true);
        }
    }

    /** Nur Spieler duerfen das Offline-Entity toeten - kein Umgebungsschaden. */
    @EventHandler(priority = EventPriority.HIGH)
    public void onDamage(EntityDamageEvent e) {
        if (!plugin.offlineEntities().istOfflineEntity(e.getEntity())) return;

        switch (e.getCause()) {
            case ENTITY_ATTACK, ENTITY_SWEEP_ATTACK, PROJECTILE, ENTITY_EXPLOSION,
                 MAGIC, THORNS, CUSTOM -> { /* erlaubt */ }
            default -> e.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onEntityDeath(EntityDeathEvent e) {
        Entity entity = e.getEntity();
        UUID spielerId = plugin.offlineEntities().spielerVon(entity);
        if (spielerId == null) return;

        e.getDrops().clear();
        e.setDroppedExp(0);

        VaroPlayer vp = plugin.data().get(spielerId);
        if (vp == null || !vp.lebt()) return;

        // Kill dem Toeter gutschreiben
        Player killer = e.getEntity().getKiller();
        String grund = "Offline-Entity getoetet";
        if (killer != null) {
            VaroPlayer vk = plugin.data().getOrCreate(killer);
            vk.kills(vk.kills() + 1);
            grund = "offline getoetet von " + killer.getName();
        }

        // Inventar-Snapshot droppen
        if (plugin.settings().offlineInventarDroppen() && vp.offlineInventar() != null) {
            Location loc = entity.getLocation();
            for (ItemStack item : vp.offlineInventar()) {
                if (item != null && !item.getType().isAir()) {
                    loc.getWorld().dropItemNaturally(loc, item);
                }
            }
            vp.offlineInventar(null);
        }

        if (plugin.settings().offlineToetenToetet()) {
            plugin.deathManager().spielerAusscheiden(vp, grund);
        }
    }
}
