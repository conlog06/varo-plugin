package de.varo.listener;

import de.varo.VaroPlugin;
import org.bukkit.entity.*;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;

public class CombatListener implements Listener {

    private final VaroPlugin plugin;

    public CombatListener(VaroPlugin plugin) {
        this.plugin = plugin;
    }

    /** Blockt Spieler-gegen-Spieler-Schaden, solange PvP aus ist. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPvp(EntityDamageByEntityEvent e) {
        if (!(e.getEntity() instanceof Player opfer)) return;

        Player angreifer = ermittleAngreifer(e.getDamager());
        if (angreifer == null) return;
        if (angreifer.getUniqueId().equals(opfer.getUniqueId())) return;

        if (pvpErlaubt()) return;

        e.setCancelled(true);
        if (e.getDamager() instanceof Player) {
            angreifer.sendMessage(plugin.messages().chat("pvp-aus"));
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDamage(EntityDamageByEntityEvent e) {
        if (!(e.getEntity() instanceof Player opfer)) return;

        Player angreifer = ermittleAngreifer(e.getDamager());
        if (angreifer == null) return;
        if (!pvpErlaubt()) return;

        plugin.combatTag().tag(angreifer, opfer);
    }

    /** PvP ist an, wenn es explizit aktiviert ist oder der eingestellte Projekttag erreicht wurde. */
    private boolean pvpErlaubt() {
        if (plugin.settings().pvpAktiv()) return true;
        int abTag = plugin.settings().pvpAbTag();
        return abTag > 0 && plugin.dayManager().projektTag() >= abTag;
    }

    private Player ermittleAngreifer(Entity damager) {
        if (damager instanceof Player p) return p;
        if (damager instanceof Projectile proj && proj.getShooter() instanceof Player p) return p;
        if (damager instanceof TNTPrimed tnt && tnt.getSource() instanceof Player p) return p;
        return null;
    }
}
