package de.varo.data;

import org.bukkit.inventory.ItemStack;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

public class VaroPlayer {

    private final UUID uuid;
    private String name;

    private boolean lebt = true;
    private String todesgrund = "";
    private long todesZeit = 0L;

    /** Joins am zuletzt gespielten Tag. */
    private int joinsHeute = 0;
    private String letzterTag = "";          // ISO-Datum in Projekt-Zeitzone
    private long letztesSessionEnde = 0L;    // epoch millis

    private int strikes = 0;
    private final List<String> strikeGruende = new ArrayList<>();

    private String team = null;
    private int kills = 0;
    private int tode = 0;
    private long spielzeitSekunden = 0L;

    /** Maximale Herzen (nicht Halbherzen). 10.0 = volle Leiste. */
    private double maxHerzen = 10.0;
    /** Letzter Tag, an dem der Spieler mindestens einmal online war (ISO). */
    private String letzterSpieltag = "";

    private ItemStack[] rucksack = null;
    private ItemStack[] offlineInventar = null;
    private UUID offlineEntity = null;

    public VaroPlayer(UUID uuid, String name) {
        this.uuid = uuid;
        this.name = name;
    }

    public UUID uuid() { return uuid; }
    public String name() { return name; }
    public void name(String n) { this.name = n; }

    public boolean lebt() { return lebt; }
    public void lebt(boolean b) { this.lebt = b; }

    public String todesgrund() { return todesgrund; }
    public void todesgrund(String g) { this.todesgrund = g; }

    public long todesZeit() { return todesZeit; }
    public void todesZeit(long t) { this.todesZeit = t; }

    public int joinsHeute() { return joinsHeute; }
    public void joinsHeute(int v) { this.joinsHeute = v; }

    public String letzterTag() { return letzterTag; }
    public void letzterTag(String s) { this.letzterTag = s; }

    public long letztesSessionEnde() { return letztesSessionEnde; }
    public void letztesSessionEnde(long v) { this.letztesSessionEnde = v; }

    public int strikes() { return strikes; }
    public void strikes(int v) { this.strikes = v; }

    public List<String> strikeGruende() { return strikeGruende; }

    public String team() { return team; }
    public void team(String t) { this.team = t; }

    public int kills() { return kills; }
    public void kills(int k) { this.kills = k; }

    public int tode() { return tode; }
    public void tode(int t) { this.tode = t; }

    public double maxHerzen() { return maxHerzen; }
    public void maxHerzen(double h) { this.maxHerzen = Math.max(0.0, h); }

    public String letzterSpieltag() { return letzterSpieltag; }
    public void letzterSpieltag(String s) { this.letzterSpieltag = s; }

    public long spielzeitSekunden() { return spielzeitSekunden; }
    public void spielzeitSekunden(long v) { this.spielzeitSekunden = v; }

    public ItemStack[] rucksack() { return rucksack; }
    public void rucksack(ItemStack[] i) { this.rucksack = i; }

    public ItemStack[] offlineInventar() { return offlineInventar; }
    public void offlineInventar(ItemStack[] i) { this.offlineInventar = i; }

    public UUID offlineEntity() { return offlineEntity; }
    public void offlineEntity(UUID id) { this.offlineEntity = id; }

    /** Setzt den Tageszaehler zurueck, wenn ein neuer Projekttag begonnen hat. */
    public void tagPruefen(LocalDate heute) {
        String iso = heute.toString();
        if (!iso.equals(letzterTag)) {
            letzterTag = iso;
            joinsHeute = 0;
        }
    }

    /** Fuer den Saison-Reset: alles Spielbezogene zurueck auf Anfang. */
    public void saisonReset(boolean strikesBehalten, boolean herzenBehalten, double startHerzen) {
        lebt = true;
        todesgrund = "";
        todesZeit = 0L;
        joinsHeute = 0;
        letzterTag = "";
        letztesSessionEnde = 0L;
        kills = 0;
        spielzeitSekunden = 0L;
        rucksack = null;
        offlineInventar = null;
        offlineEntity = null;
        if (!strikesBehalten) {
            strikes = 0;
            strikeGruende.clear();
        }
        if (!herzenBehalten) {
            maxHerzen = startHerzen;
            tode = 0;
        }
    }
}
