package de.varo.data;

import org.bukkit.ChatColor;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

public class VaroTeam {

    private final String id;
    private String anzeigename;
    private ChatColor farbe = ChatColor.WHITE;
    private final Set<UUID> mitglieder = new LinkedHashSet<>();
    private ItemStack[] kiste = null;

    public VaroTeam(String id, String anzeigename) {
        this.id = id;
        this.anzeigename = anzeigename;
    }

    public String id() { return id; }
    public String anzeigename() { return anzeigename; }
    public void anzeigename(String n) { this.anzeigename = n; }

    public ChatColor farbe() { return farbe; }
    public void farbe(ChatColor c) { this.farbe = c; }

    public Set<UUID> mitglieder() { return mitglieder; }

    public List<UUID> mitgliederListe() { return new ArrayList<>(mitglieder); }

    public ItemStack[] kiste() { return kiste; }
    public void kiste(ItemStack[] i) { this.kiste = i; }
}
