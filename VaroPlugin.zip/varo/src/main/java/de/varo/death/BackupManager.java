package de.varo.death;

import de.varo.VaroPlugin;
import org.bukkit.Bukkit;
import org.bukkit.World;

import java.io.*;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * Sichert die Welten als ZIP-Archiv in den konfigurierten Ordner.
 * Keine externen Abhaengigkeiten - java.util.zip reicht voellig.
 */
public class BackupManager {

    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss");

    private final VaroPlugin plugin;

    public BackupManager(VaroPlugin plugin) {
        this.plugin = plugin;
    }

    private Path backupWurzel() {
        Path root = plugin.getServer().getWorldContainer().toPath()
                .resolve(plugin.settings().backupOrdner());
        try {
            Files.createDirectories(root);
        } catch (IOException e) {
            plugin.getLogger().warning("Backup-Ordner konnte nicht erstellt werden: " + e.getMessage());
        }
        return root;
    }

    /** Speichert alle Welten und Spieler auf die Platte. Muss im Main-Thread laufen. */
    public void weltenSpeichern() {
        Bukkit.savePlayers();
        for (World w : Bukkit.getWorlds()) {
            w.save();
        }
    }

    /**
     * Erstellt ein Backup. Der Aufruf blockiert - fuer regelmaessige Backups
     * daher async aufrufen, fuer den Tod-Reset bewusst synchron.
     *
     * @param label z.B. "auto" oder "tod-Max"
     * @return Pfad zur ZIP-Datei oder null bei Fehler
     */
    public Path erstelleBackup(String label) {
        Path ziel = backupWurzel().resolve(LocalDateTime.now(plugin.settings().zone()).format(FMT)
                + "_" + saeubere(label) + ".zip");

        Path container = plugin.getServer().getWorldContainer().toPath();
        List<String> welten = plugin.settings().backupWelten();

        try (ZipOutputStream zip = new ZipOutputStream(new BufferedOutputStream(
                Files.newOutputStream(ziel)))) {

            for (String weltname : welten) {
                Path weltOrdner = container.resolve(weltname);
                if (!Files.isDirectory(weltOrdner)) {
                    plugin.getLogger().warning("Welt nicht gefunden, wird uebersprungen: " + weltname);
                    continue;
                }
                packeOrdner(zip, weltOrdner, weltname);
            }

            // Varo-Daten mitsichern
            Path pluginOrdner = plugin.getDataFolder().toPath();
            if (Files.isDirectory(pluginOrdner)) {
                packeOrdner(zip, pluginOrdner, "varo-daten");
            }

        } catch (IOException e) {
            plugin.getLogger().severe("Backup fehlgeschlagen: " + e.getMessage());
            return null;
        }

        aufraeumen();
        plugin.getLogger().info("Backup erstellt: " + ziel.getFileName());
        return ziel;
    }

    private void packeOrdner(ZipOutputStream zip, Path ordner, String praefix) throws IOException {
        try (var stream = Files.walk(ordner)) {
            for (Path p : stream.toList()) {
                if (Files.isDirectory(p)) continue;
                // session.lock ist waehrend des Betriebs gesperrt
                if (p.getFileName().toString().equals("session.lock")) continue;

                String eintrag = praefix + "/" + ordner.relativize(p).toString().replace('\\', '/');
                try {
                    zip.putNextEntry(new ZipEntry(eintrag));
                    Files.copy(p, zip);
                    zip.closeEntry();
                } catch (IOException e) {
                    // Einzelne gesperrte Dateien duerfen das Backup nicht killen
                    plugin.getLogger().warning("Datei uebersprungen: " + eintrag + " (" + e.getMessage() + ")");
                }
            }
        }
    }

    /** Loescht die aeltesten Backups, wenn max-backups ueberschritten ist. */
    private void aufraeumen() {
        int max = plugin.settings().maxBackups();
        if (max <= 0) return;
        try (var stream = Files.list(backupWurzel())) {
            List<Path> zips = stream
                    .filter(p -> p.toString().endsWith(".zip"))
                    .sorted(Comparator.comparing(p -> p.getFileName().toString()))
                    .collect(java.util.stream.Collectors.toCollection(ArrayList::new));

            while (zips.size() > max) {
                Path alt = zips.remove(0);
                Files.deleteIfExists(alt);
                plugin.getLogger().info("Altes Backup geloescht: " + alt.getFileName());
            }
        } catch (IOException e) {
            plugin.getLogger().warning("Backup-Aufraeumen fehlgeschlagen: " + e.getMessage());
        }
    }

    private String saeubere(String s) {
        return s.replaceAll("[^a-zA-Z0-9-_]", "_");
    }

    /** Regelmaessiges Backup im Hintergrund. */
    public void starteAutomatik() {
        int minuten = plugin.settings().backupIntervall();
        if (!plugin.settings().backupAktiv() || minuten <= 0) return;

        long ticks = minuten * 60L * 20L;
        Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            weltenSpeichern(); // sync
            Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> erstelleBackup("auto"));
        }, ticks, ticks);

        plugin.getLogger().info("Automatische Backups aktiv: alle " + minuten + " Minuten.");
    }
}
