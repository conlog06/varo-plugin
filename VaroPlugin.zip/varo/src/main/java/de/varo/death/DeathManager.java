package de.varo.death;

import de.varo.VaroBootstrap;
import de.varo.VaroPlugin;
import de.varo.data.VaroPlayer;
import de.varo.util.Txt;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.Random;

/**
 * Behandelt das Ausscheiden eines Spielers und - falls konfiguriert - den
 * kompletten Welt-Reset:
 *   Tod -> Broadcast + Discord -> Countdown -> Welten sichern -> Flag schreiben -> Shutdown
 * Die eigentliche Loeschung/Neuerstellung uebernimmt der VaroBootstrap beim naechsten Start.
 */
public class DeathManager {

    private final VaroPlugin plugin;
    private boolean resetLaeuft = false;
    private BukkitTask countdownTask;

    public DeathManager(VaroPlugin plugin) {
        this.plugin = plugin;
    }

    public boolean resetLaeuft() { return resetLaeuft; }

    // ================= Tod =================

    /**
     * Zentraler Einstieg fuer jeden Spielertod.
     * Je nach Modus verliert der Spieler Herzen oder scheidet sofort aus.
     */
    public void todVerarbeiten(VaroPlayer vp, String grund) {
        if (vp == null || !vp.lebt()) return;

        if (!plugin.settings().herzverlustModus()) {
            spielerAusscheiden(vp, grund);
            return;
        }

        boolean aufgebraucht = plugin.health().herzAbziehen(vp, grund);
        if (aufgebraucht) {
            spielerAusscheiden(vp, "keine Herzen mehr");
            return;
        }

        if (plugin.settings().weltReset()) {
            starteWeltReset(vp.name(), grund);
        }
    }

    // ================= Ausscheiden =================

    public void spielerAusscheiden(VaroPlayer vp, String grund) {
        if (vp == null || !vp.lebt()) return;

        vp.lebt(false);
        vp.todesgrund(grund);
        vp.todesZeit(System.currentTimeMillis());

        plugin.offlineEntities().alleEntfernenFuer(vp);
        plugin.data().speichern();

        Bukkit.broadcast(plugin.messages().chat("tod-broadcast",
                "spieler", vp.name(), "grund", grund));

        for (Player p : Bukkit.getOnlinePlayers()) {
            p.playSound(p.getLocation(), Sound.ENTITY_WITHER_SPAWN, 0.6f, 1f);
            p.showTitle(Title.title(
                    Txt.c("&c&l" + vp.name()),
                    Txt.c("&7ist ausgeschieden"),
                    Title.Times.times(Duration.ofMillis(300), Duration.ofSeconds(3), Duration.ofMillis(500))));
        }

        if (plugin.settings().discordAktiv() && plugin.settings().discordBeiTod()) {
            plugin.discord().sende("💀 **" + vp.name() + "** ist ausgeschieden — " + grund
                    + "\n*Tag " + plugin.dayManager().projektTag()
                    + ", Season " + plugin.settings().season() + "*");
        }

        Player online = Bukkit.getPlayer(vp.uuid());
        if (online != null && !plugin.settings().weltReset()) {
            online.setGameMode(GameMode.SPECTATOR);
        }

        if (plugin.settings().weltReset()) {
            starteWeltReset(vp.name(), grund);
        }
    }

    // ================= Welt-Reset =================

    public void starteWeltReset(String ausloeser, String grund) {
        if (resetLaeuft) return;
        resetLaeuft = true;

        int sekunden = plugin.settings().resetCountdown();
        plugin.getLogger().warning("WELT-RESET eingeleitet durch: " + ausloeser + " (" + grund + ")");

        if (plugin.settings().discordAktiv() && plugin.settings().discordBeiReset()) {
            plugin.discord().sende("🌍 **Welt-Reset** in " + sekunden + " Sekunden. "
                    + "Die Welt wird gesichert, der Server stoppt und startet mit neuen Welten.");
        }

        countdownTask = Bukkit.getScheduler().runTaskTimer(plugin, new Runnable() {
            int rest = sekunden;

            @Override
            public void run() {
                if (rest <= 0) {
                    countdownTask.cancel();
                    fuehreResetAus(ausloeser);
                    return;
                }
                if (rest % 10 == 0 || rest <= 5) {
                    Component msg = plugin.messages().chat("reset-warnung", "sekunden", rest);
                    Bukkit.broadcast(msg);
                    for (Player p : Bukkit.getOnlinePlayers()) {
                        p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 1f, 0.6f);
                        p.showTitle(Title.title(
                                Txt.c("&c&l" + rest),
                                Txt.c("&7Server stoppt"),
                                Title.Times.times(Duration.ZERO, Duration.ofMillis(1100), Duration.ZERO)));
                    }
                }
                rest--;
            }
        }, 0L, 20L);
    }

    private void fuehreResetAus(String ausloeser) {
        plugin.getLogger().warning("Fuehre Welt-Reset aus...");

        // 1. Offene Container sichern, Offline-Entities entfernen
        plugin.container().alleSpeichern();
        plugin.offlineEntities().alleEntfernen();

        // 2. Welten + Spieler auf Platte schreiben
        plugin.backup().weltenSpeichern();

        // 3. Backup ziehen (synchron - der Server stoppt danach ohnehin)
        Path zip = null;
        if (plugin.settings().backupAktiv()) {
            zip = plugin.backup().erstelleBackup("season" + plugin.settings().season() + "-tod-" + ausloeser);
        }

        // 4. Spielerdaten fuer die neue Season vorbereiten
        if (plugin.settings().datenZuruecksetzen()) {
            for (VaroPlayer vp : plugin.data().alle()) {
                vp.saisonReset(plugin.settings().teamsBehalten(),
                        plugin.settings().herzenBehalten(), plugin.settings().startHerzen());
            }
            if (!plugin.settings().teamsBehalten()) {
                for (var t : new java.util.ArrayList<>(plugin.data().teams())) {
                    plugin.data().teamLoeschen(t.id());
                }
            } else {
                plugin.data().teams().forEach(t -> t.kiste(null));
            }
            plugin.settings().season(plugin.settings().season() + 1);
            plugin.settings().startDatum(java.time.LocalDate.now(plugin.settings().zone()));
            plugin.data().speichern();
        }

        // 5. Regenerations-Flag fuer den Bootstrapper schreiben
        schreibeFlag();

        // 6. Discord + Kick + Shutdown
        if (plugin.settings().discordAktiv() && plugin.settings().discordBeiReset()) {
            plugin.discord().sendeBlockierend("✅ Backup erstellt"
                    + (zip != null ? " (`" + zip.getFileName() + "`)" : "")
                    + ". Server stoppt jetzt — beim Neustart werden neue Welten erzeugt.");
        }

        Component kick = plugin.messages().plain("reset-kick", "spieler", ausloeser);
        for (Player p : Bukkit.getOnlinePlayers()) {
            p.kick(kick);
        }

        Bukkit.getScheduler().runTaskLater(plugin, Bukkit::shutdown, 20L);
    }

    private void schreibeFlag() {
        try {
            Path ordner = plugin.getDataFolder().toPath();
            Files.createDirectories(ordner);
            Path flag = ordner.resolve(VaroBootstrap.FLAG_DATEI);

            String seed = plugin.settings().neuerSeed();
            if (seed == null || seed.isBlank()) {
                seed = String.valueOf(new Random().nextLong());
            }

            String inhalt = "welten=" + String.join(",", plugin.settings().backupWelten()) + "\n"
                    + "seed=" + seed + "\n";

            Files.writeString(flag, inhalt);
            plugin.getLogger().info("Regenerations-Flag geschrieben. Neuer Seed: " + seed);

        } catch (IOException e) {
            plugin.getLogger().severe("Flag konnte nicht geschrieben werden - Welten bleiben bestehen! "
                    + e.getMessage());
        }
    }

    /** Manueller Reset per Befehl. */
    public void manuellerReset(String vonWem) {
        starteWeltReset(vonWem, "manuell ausgeloest");
    }
}
