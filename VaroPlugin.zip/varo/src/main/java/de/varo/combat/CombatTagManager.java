package de.varo.combat;

import de.varo.VaroPlugin;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Kampf-Tag im Stil moderner CraftAttack-Saisons:
 * Wer zuschlaegt oder getroffen wird, gilt X Sekunden als "im Kampf".
 * Logout in dieser Zeit = Tod.
 */
public class CombatTagManager {

    private final VaroPlugin plugin;
    /** UUID -> Zeitpunkt (epoch millis), zu dem der Tag auslaeuft. */
    private final Map<UUID, Long> tags = new HashMap<>();

    public CombatTagManager(VaroPlugin plugin) {
        this.plugin = plugin;
    }

    public void tag(Player angreifer, Player opfer) {
        if (!plugin.settings().kampfTagAktiv()) return;
        if (angreifer == null || opfer == null) return;
        if (angreifer.getUniqueId().equals(opfer.getUniqueId())) return;
        setzeTag(angreifer);
        setzeTag(opfer);
    }

    public void setzeTag(Player p) {
        if (!plugin.settings().kampfTagAktiv()) return;
        if (p.hasPermission("varo.bypass.kampftag")) return;

        boolean warNeu = !imKampf(p);
        tags.put(p.getUniqueId(), System.currentTimeMillis()
                + plugin.settings().kampfTagSekunden() * 1000L);

        if (warNeu) {
            p.sendMessage(plugin.messages().chat("kampf-tag-start",
                    "sekunden", plugin.settings().kampfTagSekunden()));
        }
    }

    public boolean imKampf(Player p) {
        Long bis = tags.get(p.getUniqueId());
        return bis != null && bis > System.currentTimeMillis();
    }

    public long restSekunden(Player p) {
        Long bis = tags.get(p.getUniqueId());
        if (bis == null) return 0;
        long rest = (bis - System.currentTimeMillis()) / 1000L;
        return Math.max(0, rest);
    }

    public void entferne(Player p) {
        tags.remove(p.getUniqueId());
    }

    /** Sekundentakt: abgelaufene Tags aufraeumen und verzoegerte Kicks nachholen. */
    public void tick() {
        long jetzt = System.currentTimeMillis();
        var it = tags.entrySet().iterator();
        boolean etwasAbgelaufen = false;

        while (it.hasNext()) {
            var e = it.next();
            if (e.getValue() <= jetzt) {
                it.remove();
                etwasAbgelaufen = true;
                Player p = Bukkit.getPlayer(e.getKey());
                if (p != null && p.isOnline()) {
                    p.sendMessage(plugin.messages().chat("kampf-tag-ende"));
                }
            }
        }

        if (etwasAbgelaufen) {
            plugin.sessionManager().pruefeVerzoegerteKicks();
        }
    }
}
