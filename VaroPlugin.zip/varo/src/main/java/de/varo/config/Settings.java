package de.varo.config;

import de.varo.VaroPlugin;
import org.bukkit.Difficulty;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.EntityType;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.List;

/**
 * Typisierter Zugriff auf die config.yml.
 * Werte, die der Admin im laufenden Projekt aendern darf, haben Setter, die direkt speichern.
 */
public class Settings {

    private final VaroPlugin plugin;

    public Settings(VaroPlugin plugin) {
        this.plugin = plugin;
    }

    private FileConfiguration cfg() {
        return plugin.getConfig();
    }

    /** Generischer Setter - wird vom Admin-GUI benutzt. */
    public void set(String pfad, Object wert) {
        cfg().set(pfad, wert);
        plugin.saveConfig();
    }

    public boolean bool(String pfad, boolean standard) { return cfg().getBoolean(pfad, standard); }
    public int zahl(String pfad, int standard) { return cfg().getInt(pfad, standard); }
    public double komma(String pfad, double standard) { return cfg().getDouble(pfad, standard); }

    /** Schaltet einen Boolean-Wert um und gibt den neuen Zustand zurueck. */
    public boolean toggle(String pfad, boolean standard) {
        boolean neu = !cfg().getBoolean(pfad, standard);
        set(pfad, neu);
        return neu;
    }

    // ---------- Zeit / Projekt ----------

    public ZoneId zone() {
        try {
            return ZoneId.of(cfg().getString("zeitzone", "Europe/Berlin"));
        } catch (Exception e) {
            return ZoneId.of("Europe/Berlin");
        }
    }

    public LocalDate startDatum() {
        String s = cfg().getString("projekt.start-datum", "");
        if (s == null || s.isBlank()) {
            LocalDate heute = LocalDate.now(zone());
            cfg().set("projekt.start-datum", heute.toString());
            plugin.saveConfig();
            return heute;
        }
        try {
            return LocalDate.parse(s);
        } catch (Exception e) {
            return LocalDate.now(zone());
        }
    }

    public void startDatum(LocalDate d) {
        cfg().set("projekt.start-datum", d.toString());
        plugin.saveConfig();
    }

    public int season() { return cfg().getInt("projekt.season", 1); }

    public void season(int s) {
        cfg().set("projekt.season", s);
        plugin.saveConfig();
    }

    public int tageswechselStunde() {
        return Math.max(0, Math.min(23, cfg().getInt("projekt.tageswechsel-stunde", 0)));
    }

    public boolean laeuft() { return cfg().getBoolean("projekt.laeuft", true); }

    public void laeuft(boolean b) {
        cfg().set("projekt.laeuft", b);
        plugin.saveConfig();
    }

    // ---------- Session (zur Laufzeit aenderbar) ----------

    public int joinsProTag() { return Math.max(1, cfg().getInt("session.joins-pro-tag", 3)); }

    public void joinsProTag(int v) {
        cfg().set("session.joins-pro-tag", Math.max(1, v));
        plugin.saveConfig();
    }

    public int sessionMinuten() { return Math.max(1, cfg().getInt("session.dauer-minuten", 60)); }

    public void sessionMinuten(int v) {
        cfg().set("session.dauer-minuten", Math.max(1, v));
        plugin.saveConfig();
    }

    public int sessionSekunden() { return sessionMinuten() * 60; }

    public int abklingzeitMinuten() { return Math.max(0, cfg().getInt("session.abklingzeit-minuten", 0)); }

    public void abklingzeitMinuten(int v) {
        cfg().set("session.abklingzeit-minuten", Math.max(0, v));
        plugin.saveConfig();
    }

    public List<Integer> warnungen() {
        return cfg().getIntegerList("session.warnungen-sekunden");
    }

    public int titelAbSekunde() { return cfg().getInt("session.titel-ab-sekunde", 10); }

    public boolean actionbar() { return cfg().getBoolean("session.actionbar", true); }

    // ---------- Kampf-Tag ----------

    public boolean kampfTagAktiv() { return cfg().getBoolean("kampf-tag.aktiv", true); }
    public int kampfTagSekunden() { return Math.max(1, cfg().getInt("kampf-tag.dauer-sekunden", 15)); }
    public boolean kampfLogoutToetet() { return cfg().getBoolean("kampf-tag.logout-toetet", true); }
    public boolean kickVerzoegern() { return cfg().getBoolean("kampf-tag.kick-verzoegern", true); }

    // ---------- Offline-Entity ----------

    public boolean offlineEntityAktiv() { return cfg().getBoolean("offline-entity.aktiv", true); }

    public EntityType offlineEntityTyp() {
        try {
            return EntityType.valueOf(cfg().getString("offline-entity.typ", "ZOMBIE").toUpperCase());
        } catch (Exception e) {
            return EntityType.ZOMBIE;
        }
    }

    public boolean offlineAusruestung() { return cfg().getBoolean("offline-entity.ausruestung-kopieren", true); }
    public boolean offlineToetenToetet() { return cfg().getBoolean("offline-entity.toeten-toetet-spieler", true); }
    public boolean offlineInventarDroppen() { return cfg().getBoolean("offline-entity.inventar-droppen", true); }

    // ---------- Strikes ----------

    public boolean strikesAktiv() { return cfg().getBoolean("strikes.aktiv", true); }
    public int strikeMaximum() { return Math.max(1, cfg().getInt("strikes.maximum", 3)); }

    // ---------- Rucksack / Teamkiste ----------

    public boolean rucksackAktiv() { return cfg().getBoolean("rucksack.aktiv", true); }
    public int rucksackZeilen() { return Math.max(1, Math.min(6, cfg().getInt("rucksack.zeilen", 3))); }
    public String rucksackTitel() { return cfg().getString("rucksack.titel", "&8» &6Rucksack"); }
    public boolean rucksackImKampfGesperrt() { return cfg().getBoolean("rucksack.im-kampf-gesperrt", true); }

    public boolean teamkisteAktiv() { return cfg().getBoolean("teamkiste.aktiv", true); }
    public int teamkisteZeilen() { return Math.max(1, Math.min(6, cfg().getInt("teamkiste.zeilen", 6))); }
    public String teamkisteTitel() { return cfg().getString("teamkiste.titel", "&8» &bTeamkiste"); }
    public boolean teamkisteImKampfGesperrt() { return cfg().getBoolean("teamkiste.im-kampf-gesperrt", true); }

    // ---------- Tod / Reset ----------

    public boolean weltReset() { return cfg().getBoolean("tod.welt-reset", true); }
    public int resetCountdown() { return Math.max(1, cfg().getInt("tod.countdown-sekunden", 30)); }
    public boolean datenZuruecksetzen() { return cfg().getBoolean("tod.daten-zuruecksetzen", true); }
    public boolean teamsBehalten() { return cfg().getBoolean("tod.teams-behalten", true); }
    public String neuerSeed() { return cfg().getString("tod.neuer-seed", ""); }

    // ---------- Backup ----------

    public boolean backupAktiv() { return cfg().getBoolean("backup.aktiv", true); }
    public String backupOrdner() { return cfg().getString("backup.ordner", "varo-backups"); }
    public int backupIntervall() { return cfg().getInt("backup.intervall-minuten", 120); }
    public int maxBackups() { return cfg().getInt("backup.max-backups", 10); }

    public List<String> backupWelten() {
        List<String> l = cfg().getStringList("backup.welten");
        return l.isEmpty() ? List.of("world", "world_nether", "world_the_end") : l;
    }

    // ---------- Discord ----------

    public boolean discordAktiv() { return cfg().getBoolean("discord.aktiv", false); }
    public String webhook() { return cfg().getString("discord.webhook-url", ""); }
    public String discordName() { return cfg().getString("discord.name", "Varo"); }
    public boolean discordBeiTod() { return cfg().getBoolean("discord.bei-tod", true); }
    public boolean discordBeiStrike() { return cfg().getBoolean("discord.bei-strike", true); }
    public boolean discordBeiReset() { return cfg().getBoolean("discord.bei-welt-reset", true); }
    public boolean discordBeiJoinQuit() { return cfg().getBoolean("discord.bei-join-quit", false); }

    // ---------- Anzeige ----------

    public boolean scoreboardAktiv() { return cfg().getBoolean("scoreboard.aktiv", true); }
    public String scoreboardTitel() { return cfg().getString("scoreboard.titel", "&6&lVARO"); }
    public int scoreboardTicks() { return Math.max(5, cfg().getInt("scoreboard.update-ticks", 20)); }

    public boolean tablistAktiv() { return cfg().getBoolean("tablist.aktiv", true); }
    public List<String> tablistHeader() { return cfg().getStringList("tablist.header"); }
    public List<String> tablistFooter() { return cfg().getStringList("tablist.footer"); }

    public boolean nametagsAktiv() { return cfg().getBoolean("nametags.aktiv", true); }
    public boolean nametagPraefix() { return cfg().getBoolean("nametags.praefix", true); }

    // ---------- Auto-Setup ----------

    public boolean autoSetup() { return cfg().getBoolean("auto-setup.aktiv", true); }

    public Difficulty schwierigkeit() {
        try {
            return Difficulty.valueOf(cfg().getString("auto-setup.schwierigkeit", "HARD").toUpperCase());
        } catch (Exception e) {
            return Difficulty.HARD;
        }
    }

    public double weltgrenze() { return cfg().getDouble("auto-setup.weltgrenze", 3000); }
    public boolean spawnschutzAus() { return cfg().getBoolean("auto-setup.spawnschutz-aus", true); }

    // ---------- Oeffnungszeiten ----------

    public boolean oeffnungAktiv() { return cfg().getBoolean("oeffnungszeiten.aktiv", true); }
    public int oeffnetStunde() { return clamp(cfg().getInt("oeffnungszeiten.oeffnet-stunde", 6), 0, 23); }
    public int oeffnetMinute() { return clamp(cfg().getInt("oeffnungszeiten.oeffnet-minute", 0), 0, 59); }
    public int schliesstStunde() { return clamp(cfg().getInt("oeffnungszeiten.schliesst-stunde", 23), 0, 23); }
    public int schliesstMinute() { return clamp(cfg().getInt("oeffnungszeiten.schliesst-minute", 59), 0, 59); }

    public java.util.List<Integer> schlussWarnungen() {
        java.util.List<Integer> l = cfg().getIntegerList("oeffnungszeiten.warnungen-minuten");
        return l.isEmpty() ? java.util.List.of(60, 30, 10, 5, 1) : l;
    }

    public String oeffnetText() {
        return String.format("%02d:%02d", oeffnetStunde(), oeffnetMinute());
    }

    public String schliesstText() {
        return String.format("%02d:%02d", schliesstStunde(), schliesstMinute());
    }

    // ---------- PvP ----------

    public boolean pvpAktiv() { return cfg().getBoolean("pvp.aktiv", false); }
    public int pvpAbTag() { return cfg().getInt("pvp.ab-tag", 0); }

    // ---------- Strikes (Erweiterung) ----------

    public boolean inaktivitaetAktiv() { return cfg().getBoolean("strikes.inaktivitaet-aktiv", true); }
    public int inaktivitaetAbTag() { return Math.max(1, cfg().getInt("strikes.inaktivitaet-ab-tag", 2)); }

    // ---------- Tod / Herzen ----------

    public String todModus() { return cfg().getString("tod.modus", "HERZVERLUST").toUpperCase(); }
    public boolean herzverlustModus() { return todModus().startsWith("HERZ"); }
    public double herzverlust() { return Math.max(0.5, cfg().getDouble("tod.herzverlust", 0.5)); }
    public double startHerzen() { return Math.max(0.5, cfg().getDouble("tod.start-herzen", 10.0)); }
    public double minimumHerzen() { return Math.max(0.0, cfg().getDouble("tod.minimum-herzen", 0.5)); }
    public boolean herzenBehalten() { return cfg().getBoolean("tod.herzen-behalten", true); }

    // ---------- Discord (Erweiterung) ----------

    public boolean discordBeiStrafe() { return cfg().getBoolean("discord.bei-strafe", true); }
    public boolean discordBeiServerzeiten() { return cfg().getBoolean("discord.bei-serverzeiten", false); }

    private int clamp(int wert, int min, int max) {
        return Math.max(min, Math.min(max, wert));
    }
}
