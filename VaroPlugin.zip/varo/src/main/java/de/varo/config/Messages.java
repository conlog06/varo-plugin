package de.varo.config;

import de.varo.VaroPlugin;
import de.varo.util.Txt;
import net.kyori.adventure.text.Component;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;

public class Messages {

    private final VaroPlugin plugin;
    private FileConfiguration cfg;

    public Messages(VaroPlugin plugin) {
        this.plugin = plugin;
        laden();
    }

    public void laden() {
        File f = new File(plugin.getDataFolder(), "messages.yml");
        if (!f.exists()) plugin.saveResource("messages.yml", false);
        cfg = YamlConfiguration.loadConfiguration(f);
    }

    public String praefix() {
        return cfg.getString("praefix", "&8[&6Varo&8] &7");
    }

    /** Rohtext ohne Praefix, mit ersetzten Platzhaltern. */
    public String raw(String key, Object... pairs) {
        return Txt.fill(cfg.getString(key, "&c<fehlende Nachricht: " + key + ">"), pairs);
    }

    /** Component mit Praefix - fuer Chat. */
    public Component chat(String key, Object... pairs) {
        return Txt.c(praefix() + raw(key, pairs));
    }

    /** Component ohne Praefix - fuer Kick-Screens, Titel, Actionbar. */
    public Component plain(String key, Object... pairs) {
        return Txt.c(raw(key, pairs));
    }
}
