package de.varo.ui;

import de.varo.VaroPlugin;
import de.varo.data.VaroPlayer;
import de.varo.data.VaroTeam;
import de.varo.util.TimeUtil;
import de.varo.util.Txt;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.*;

import java.util.ArrayList;
import java.util.List;

/**
 * Scoreboard (Sidebar), Tablist, Nametags und Actionbar.
 * Jeder Spieler bekommt ein eigenes Scoreboard, damit die Restzeit individuell ist.
 * Die Zeilen werden ueber Team-Praefixe gesetzt - dadurch flackert nichts.
 */
public class DisplayManager {

    private static final ChatColor[] EINTRAEGE = ChatColor.values();

    private final VaroPlugin plugin;

    public DisplayManager(VaroPlugin plugin) {
        this.plugin = plugin;
    }

    // ================= Einrichtung =================

    public void einrichten(Player p) {
        if (!plugin.settings().scoreboardAktiv()) return;
        Scoreboard sb = Bukkit.getScoreboardManager().getNewScoreboard();

        Objective obj = sb.registerNewObjective("varo", Criteria.DUMMY,
                Txt.c(plugin.settings().scoreboardTitel()));
        obj.setDisplaySlot(DisplaySlot.SIDEBAR);

        p.setScoreboard(sb);
        aktualisiere(p);
    }

    public void entfernen(Player p) {
        p.setScoreboard(Bukkit.getScoreboardManager().getMainScoreboard());
    }

    // ================= Takt =================

    public void tick() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            aktualisiere(p);
            actionbar(p);
        }
    }

    public void aktualisiere(Player p) {
        if (plugin.settings().scoreboardAktiv()) sidebar(p);
        if (plugin.settings().tablistAktiv()) tablist(p);
        if (plugin.settings().nametagsAktiv()) nametags(p);
    }

    // ================= Sidebar =================

    private void sidebar(Player p) {
        Scoreboard sb = p.getScoreboard();
        if (sb == null || sb.getObjective("varo") == null) {
            einrichten(p);
            return;
        }
        Objective obj = sb.getObjective("varo");
        obj.displayName(Txt.c(plugin.settings().scoreboardTitel()));

        List<String> zeilen = baueZeilen(p);

        // Ueberzaehlige Eintraege entfernen
        for (String eintrag : new ArrayList<>(sb.getEntries())) {
            int idx = indexVonEintrag(eintrag);
            if (idx < 0 || idx >= zeilen.size()) {
                sb.resetScores(eintrag);
            }
        }

        for (int i = 0; i < zeilen.size(); i++) {
            String eintrag = eintragFuer(i);
            String teamName = "line" + i;

            Team t = sb.getTeam(teamName);
            if (t == null) {
                t = sb.registerNewTeam(teamName);
                t.addEntry(eintrag);
            }
            t.prefix(Txt.c(zeilen.get(i)));
            obj.getScore(eintrag).setScore(zeilen.size() - i);
        }
    }

    /** Unsichtbarer, eindeutiger Eintrag pro Zeile (Farbcode-Kombination). */
    private String eintragFuer(int index) {
        return ChatColor.COLOR_CHAR + "" + EINTRAEGE[index % EINTRAEGE.length].getChar()
                + ChatColor.RESET;
    }

    private int indexVonEintrag(String eintrag) {
        for (int i = 0; i < 20; i++) {
            if (eintragFuer(i).equals(eintrag)) return i;
        }
        return -1;
    }

    private List<String> baueZeilen(Player p) {
        VaroPlayer vp = plugin.data().getOrCreate(p);
        VaroTeam team = plugin.data().teamVon(vp);
        var s = plugin.settings();

        List<String> l = new ArrayList<>();
        l.add("&8&m                    ");
        l.add("&7Tag &f" + plugin.dayManager().projektTag() + " &8| &7Season &f" + s.season());

        long rest = plugin.sessionManager().restSekunden(p);
        l.add("&7Zeit &f" + (rest < 0 ? "∞" : TimeUtil.format(rest)));
        l.add("&7Joins &f" + vp.joinsHeute() + "&7/&f" + s.joinsProTag());

        l.add("&8&m                   &r ");

        if (team != null) {
            l.add("&7Team " + team.farbe() + team.anzeigename());
        }
        if (s.strikesAktiv()) {
            l.add("&7Strikes &f" + vp.strikes() + "&7/&f" + s.strikeMaximum());
        }
        l.add("&7Herzen &c" + de.varo.health.HealthManager.format(vp.maxHerzen()) + " ♥");
        l.add("&7Am Leben &f" + plugin.data().lebende().size() + "&7/&f" + plugin.data().alle().size());

        if (plugin.combatTag().imKampf(p)) {
            l.add("&c⚔ Kampf &f" + plugin.combatTag().restSekunden(p) + "s");
        }

        l.add("&8&m                  &r  ");
        if (s.oeffnungAktiv()) {
            l.add("&8Server bis " + s.schliesstText() + " Uhr");
        } else {
            l.add("&8" + plugin.dayManager().heute());
        }

        return l;
    }

    // ================= Tablist =================

    private void tablist(Player p) {
        VaroPlayer vp = plugin.data().getOrCreate(p);
        long rest = plugin.sessionManager().restSekunden(p);

        Object[] platzhalter = {
                "tag", plugin.dayManager().projektTag(),
                "season", plugin.settings().season(),
                "restzeit", rest < 0 ? "∞" : TimeUtil.format(rest),
                "joins", vp.joinsHeute(),
                "maxjoins", plugin.settings().joinsProTag(),
                "lebende", plugin.data().lebende().size(),
                "spieler", p.getName()
        };

        Component header = joinZeilen(plugin.settings().tablistHeader(), platzhalter);
        Component footer = joinZeilen(plugin.settings().tablistFooter(), platzhalter);
        p.sendPlayerListHeaderAndFooter(header, footer);

        // Name in der Tabliste einfaerben
        VaroTeam team = plugin.data().teamVon(vp);
        String farbe = vp.lebt() ? (team != null ? team.farbe().toString() : "&f") : "&8&m";
        p.playerListName(Txt.c(farbe.replace(ChatColor.COLOR_CHAR, '&') + p.getName()));
    }

    private Component joinZeilen(List<String> zeilen, Object... platzhalter) {
        if (zeilen == null || zeilen.isEmpty()) return Component.empty();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < zeilen.size(); i++) {
            if (i > 0) sb.append("\n");
            sb.append(Txt.fill(zeilen.get(i), platzhalter));
        }
        return Txt.c(sb.toString());
    }

    // ================= Nametags =================

    private void nametags(Player betrachter) {
        Scoreboard sb = betrachter.getScoreboard();
        if (sb == null) return;

        for (Player ziel : Bukkit.getOnlinePlayers()) {
            VaroPlayer vp = plugin.data().getOrCreate(ziel);
            VaroTeam team = plugin.data().teamVon(vp);

            String teamName = "nt_" + (team != null ? kuerze(team.id(), 12) : (vp.lebt() ? "solo" : "tot"));

            Team t = sb.getTeam(teamName);
            if (t == null) t = sb.registerNewTeam(teamName);

            if (plugin.settings().nametagPraefix()) {
                if (!vp.lebt()) {
                    t.prefix(Txt.c("&8☠ "));
                    t.color(net.kyori.adventure.text.format.NamedTextColor.DARK_GRAY);
                } else if (team != null) {
                    t.prefix(Txt.c("&" + team.farbe().getChar() + "▎"));
                } else {
                    t.prefix(Component.empty());
                }
            }
            t.setAllowFriendlyFire(true);

            if (!t.hasEntry(ziel.getName())) {
                // Aus altem Team entfernen
                Team alt = sb.getEntryTeam(ziel.getName());
                if (alt != null && !alt.getName().equals(teamName)) alt.removeEntry(ziel.getName());
                t.addEntry(ziel.getName());
            }
        }
    }

    private String kuerze(String s, int max) {
        return s.length() <= max ? s : s.substring(0, max);
    }

    // ================= Actionbar =================

    private void actionbar(Player p) {
        if (!plugin.settings().actionbar()) return;

        long rest = plugin.sessionManager().restSekunden(p);
        StringBuilder sb = new StringBuilder();

        if (rest >= 0) {
            String farbe = rest <= 30 ? "&c" : rest <= 300 ? "&e" : "&a";
            sb.append("&7Session ").append(farbe).append(TimeUtil.format(rest));
        } else if (!plugin.settings().laeuft()) {
            sb.append("&8Projekt pausiert");
        }

        if (plugin.settings().oeffnungAktiv()) {
            long bisSchluss = plugin.oeffnungszeiten().sekundenBisSchluss();
            if (bisSchluss > 0 && bisSchluss <= 3600) {
                if (sb.length() > 0) sb.append(" &8| ");
                sb.append("&6Server schließt in ").append(TimeUtil.format(bisSchluss));
            }
        }

        if (plugin.combatTag().imKampf(p)) {
            if (sb.length() > 0) sb.append(" &8| ");
            sb.append("&c⚔ ").append(plugin.combatTag().restSekunden(p)).append("s");
        }

        if (sb.length() > 0) {
            p.sendActionBar(Txt.c(sb.toString()));
        }
    }
}
