package de.varo.discord;

import de.varo.VaroPlugin;
import org.bukkit.Bukkit;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.nio.charset.StandardCharsets;

/**
 * Discord-Anbindung ueber Webhook - bewusst ohne JDA, damit das Plugin
 * abhaengigkeitsfrei bleibt. Alle Aufrufe laufen asynchron.
 */
public class DiscordNotifier {

    private final VaroPlugin plugin;

    public DiscordNotifier(VaroPlugin plugin) {
        this.plugin = plugin;
    }

    public void sende(String nachricht) {
        if (!plugin.settings().discordAktiv()) return;
        String url = plugin.settings().webhook();
        if (url == null || url.isBlank()) return;

        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> post(url, nachricht));
    }

    /** Synchron - nur benutzen, wenn der Server ohnehin gleich stoppt. */
    public void sendeBlockierend(String nachricht) {
        if (!plugin.settings().discordAktiv()) return;
        String url = plugin.settings().webhook();
        if (url == null || url.isBlank()) return;
        post(url, nachricht);
    }

    private void post(String url, String nachricht) {
        try {
            HttpURLConnection con = (HttpURLConnection) URI.create(url).toURL().openConnection();
            con.setRequestMethod("POST");
            con.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            con.setRequestProperty("User-Agent", "VaroPlugin");
            con.setConnectTimeout(5000);
            con.setReadTimeout(5000);
            con.setDoOutput(true);

            String body = "{\"username\":\"" + escape(plugin.settings().discordName())
                    + "\",\"content\":\"" + escape(nachricht) + "\"}";

            try (OutputStream os = con.getOutputStream()) {
                os.write(body.getBytes(StandardCharsets.UTF_8));
            }

            int code = con.getResponseCode();
            if (code >= 300) {
                plugin.getLogger().warning("Discord-Webhook antwortete mit HTTP " + code);
            }
            con.disconnect();

        } catch (Exception e) {
            plugin.getLogger().warning("Discord-Webhook fehlgeschlagen: " + e.getMessage());
        }
    }

    private String escape(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "");
    }
}
