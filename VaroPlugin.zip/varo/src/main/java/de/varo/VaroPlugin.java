package de.varo;

import de.varo.combat.CombatTagManager;
import de.varo.command.VaroBasicCommand;
import de.varo.command.VaroCommand;
import de.varo.config.Messages;
import de.varo.config.Settings;
import de.varo.death.BackupManager;
import de.varo.death.DeathManager;
import de.varo.discord.DiscordNotifier;
import de.varo.listener.*;
import de.varo.offline.OfflineEntityManager;
import de.varo.session.DayManager;
import de.varo.gui.AdminGui;
import de.varo.health.HealthManager;
import de.varo.session.OpeningHoursManager;
import de.varo.session.SessionManager;
import de.varo.storage.ContainerManager;
import de.varo.storage.DataStore;
import de.varo.strike.StrikeManager;
import de.varo.ui.DisplayManager;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.List;

public class VaroPlugin extends JavaPlugin {

    private Settings settings;
    private Messages messages;
    private DataStore data;

    private DayManager dayManager;
    private SessionManager sessionManager;
    private CombatTagManager combatTag;
    private OfflineEntityManager offlineEntities;
    private StrikeManager strikes;
    private ContainerManager container;
    private DeathManager deathManager;
    private BackupManager backup;
    private DiscordNotifier discord;
    private DisplayManager display;
    private OpeningHoursManager oeffnungszeiten;
    private HealthManager health;
    private AdminGui adminGui;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        getConfig().options().copyDefaults(true);
        saveConfig();

        settings = new Settings(this);
        messages = new Messages(this);
        data = new DataStore(this);
        data.laden();

        dayManager = new DayManager(this);
        sessionManager = new SessionManager(this);
        combatTag = new CombatTagManager(this);
        offlineEntities = new OfflineEntityManager(this);
        strikes = new StrikeManager(this);
        container = new ContainerManager(this);
        backup = new BackupManager(this);
        discord = new DiscordNotifier(this);
        deathManager = new DeathManager(this);
        display = new DisplayManager(this);
        oeffnungszeiten = new OpeningHoursManager(this);
        health = new HealthManager(this);
        adminGui = new AdminGui(this);

        settings.startDatum(); // legt das Startdatum beim ersten Start an

        registriereListener();
        registriereBefehle();

        Bukkit.getScheduler().runTask(this, () -> {
            new de.varo.setup.AutoSetup(this).ausfuehren();
            offlineEntities.wiederherstellen();
        });

        starteTakt();
        backup.starteAutomatik();

        getLogger().info("Serverzeitfenster: " + settings.oeffnetText() + " - "
                + settings.schliesstText() + " Uhr (" + (settings.oeffnungAktiv() ? "aktiv" : "aus") + ")");
        getLogger().info("VaroPlugin aktiv - Season " + settings.season()
                + ", Tag " + dayManager.projektTag()
                + ", Zeitzone " + settings.zone());
    }

    @Override
    public void onDisable() {
        if (container != null) container.alleSpeichern();
        for (var p : Bukkit.getOnlinePlayers()) {
            if (sessionManager != null) sessionManager.beendeSession(p, false);
        }
        if (data != null) data.speichern();
        getLogger().info("VaroPlugin deaktiviert - Daten gespeichert.");
    }

    private void registriereListener() {
        var pm = Bukkit.getPluginManager();
        pm.registerEvents(new PlayerListener(this), this);
        pm.registerEvents(new CombatListener(this), this);
        pm.registerEvents(new OfflineEntityListener(this), this);
        pm.registerEvents(new ContainerListener(this), this);
        pm.registerEvents(new de.varo.listener.GuiListener(this), this);
    }

    /**
     * Paper-Plugins registrieren Befehle im Code, nicht in der YAML.
     * JavaPlugin#getCommand wirft hier eine UnsupportedOperationException.
     */
    private void registriereBefehle() {
        VaroCommand handler = new VaroCommand(this);

        registerCommand("varo", "Hauptbefehl des Varo-Plugins",
                List.of("v"), new VaroBasicCommand("varo", handler));

        registerCommand("rucksack", "Oeffnet den persoenlichen Rucksack",
                List.of("rs", "backpack"), new VaroBasicCommand("rucksack", handler));

        registerCommand("teamkiste", "Oeffnet die gemeinsame Teamkiste",
                List.of("tk", "teamchest"), new VaroBasicCommand("teamkiste", handler));
    }

    /** Ein einziger Sekundentakt fuer alle zeitabhaengigen Systeme. */
    private void starteTakt() {
        Bukkit.getScheduler().runTaskTimer(this, () -> {
            dayManager.tick();
            oeffnungszeiten.tick();
            combatTag.tick();
            sessionManager.tick();
        }, 20L, 20L);

        Bukkit.getScheduler().runTaskTimer(this, () -> display.tick(),
                20L, settings.scoreboardTicks());
    }

    // ================= Zugriff =================

    public Settings settings() { return settings; }
    public Messages messages() { return messages; }
    public DataStore data() { return data; }
    public DayManager dayManager() { return dayManager; }
    public SessionManager sessionManager() { return sessionManager; }
    public CombatTagManager combatTag() { return combatTag; }
    public OfflineEntityManager offlineEntities() { return offlineEntities; }
    public StrikeManager strikes() { return strikes; }
    public ContainerManager container() { return container; }
    public DeathManager deathManager() { return deathManager; }
    public BackupManager backup() { return backup; }
    public DiscordNotifier discord() { return discord; }
    public DisplayManager display() { return display; }
    public OpeningHoursManager oeffnungszeiten() { return oeffnungszeiten; }
    public HealthManager health() { return health; }
    public AdminGui adminGui() { return adminGui; }
}
