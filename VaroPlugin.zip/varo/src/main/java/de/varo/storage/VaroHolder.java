package de.varo.storage;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.jetbrains.annotations.NotNull;

/** Markiert Rucksack- und Teamkisten-Inventare, damit der Listener sie wiedererkennt. */
public class VaroHolder implements InventoryHolder {

    public enum Typ { RUCKSACK, TEAMKISTE }

    private final Typ typ;
    private final String besitzer; // UUID-String oder Team-ID
    private Inventory inventory;

    public VaroHolder(Typ typ, String besitzer) {
        this.typ = typ;
        this.besitzer = besitzer;
    }

    public Typ typ() { return typ; }
    public String besitzer() { return besitzer; }

    public void setInventory(Inventory inv) { this.inventory = inv; }

    @Override
    public @NotNull Inventory getInventory() {
        return inventory;
    }
}
