package de.varo.storage;

import de.varo.VaroPlugin;
import de.varo.data.VaroPlayer;
import de.varo.data.VaroTeam;
import de.varo.util.Txt;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.HashMap;
import java.util.Map;

/**
 * Rucksack (pro Spieler) und Teamkiste (pro Team).
 * Teamkisten werden zwischengehalten, damit mehrere Teammitglieder gleichzeitig
 * dasselbe Inventar sehen und Items nicht dupliziert werden.
 */
public class ContainerManager {

    private final VaroPlugin plugin;
    private final Map<String, Inventory> offeneTeamkisten = new HashMap<>();

    public ContainerManager(VaroPlugin plugin) {
        this.plugin = plugin;
    }

    // ================= Rucksack =================

    public void oeffneRucksack(Player p) {
        if (!plugin.settings().rucksackAktiv()) return;

        if (plugin.settings().rucksackImKampfGesperrt() && plugin.combatTag().imKampf(p)) {
            p.sendMessage(plugin.messages().chat("im-kampf-gesperrt"));
            return;
        }

        VaroPlayer vp = plugin.data().getOrCreate(p);
        int size = plugin.settings().rucksackZeilen() * 9;

        VaroHolder holder = new VaroHolder(VaroHolder.Typ.RUCKSACK, p.getUniqueId().toString());
        Inventory inv = Bukkit.createInventory(holder, size, Txt.c(plugin.settings().rucksackTitel()));
        holder.setInventory(inv);

        ItemStack[] inhalt = vp.rucksack();
        if (inhalt != null) {
            for (int i = 0; i < Math.min(inhalt.length, size); i++) {
                inv.setItem(i, inhalt[i]);
            }
        }
        p.openInventory(inv);
    }

    public void speichereRucksack(String uuidString, Inventory inv) {
        try {
            VaroPlayer vp = plugin.data().get(java.util.UUID.fromString(uuidString));
            if (vp == null) return;
            vp.rucksack(inv.getContents());
            plugin.data().speichern();
        } catch (IllegalArgumentException ignored) {}
    }

    // ================= Teamkiste =================

    public void oeffneTeamkiste(Player p) {
        if (!plugin.settings().teamkisteAktiv()) return;

        if (plugin.settings().teamkisteImKampfGesperrt() && plugin.combatTag().imKampf(p)) {
            p.sendMessage(plugin.messages().chat("im-kampf-gesperrt"));
            return;
        }

        VaroPlayer vp = plugin.data().getOrCreate(p);
        VaroTeam team = plugin.data().teamVon(vp);
        if (team == null) {
            p.sendMessage(Txt.c(plugin.messages().praefix() + "&cDu bist in keinem Team."));
            return;
        }

        Inventory inv = offeneTeamkisten.get(team.id());
        if (inv == null) {
            int size = plugin.settings().teamkisteZeilen() * 9;
            VaroHolder holder = new VaroHolder(VaroHolder.Typ.TEAMKISTE, team.id());
            inv = Bukkit.createInventory(holder, size,
                    Txt.c(plugin.settings().teamkisteTitel() + " &8• &7" + team.anzeigename()));
            holder.setInventory(inv);

            ItemStack[] inhalt = team.kiste();
            if (inhalt != null) {
                for (int i = 0; i < Math.min(inhalt.length, size); i++) {
                    inv.setItem(i, inhalt[i]);
                }
            }
            offeneTeamkisten.put(team.id(), inv);
        }
        p.openInventory(inv);
    }

    public void speichereTeamkiste(String teamId, Inventory inv) {
        VaroTeam team = plugin.data().team(teamId);
        if (team == null) return;
        team.kiste(inv.getContents());
        plugin.data().speichern();

        // Wenn niemand mehr zuschaut, aus dem Cache nehmen.
        if (inv.getViewers().size() <= 1) {
            offeneTeamkisten.remove(teamId);
        }
    }

    /** Beim Shutdown alle offenen Kisten sichern. */
    public void alleSpeichern() {
        for (var e : offeneTeamkisten.entrySet()) {
            VaroTeam team = plugin.data().team(e.getKey());
            if (team != null) team.kiste(e.getValue().getContents());
        }
        offeneTeamkisten.clear();
        plugin.data().speichern();
    }
}
