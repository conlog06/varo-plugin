package de.varo.storage;

import de.varo.VaroPlugin;
import de.varo.data.VaroPlayer;
import de.varo.data.VaroTeam;
import org.bukkit.ChatColor;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.io.IOException;
import java.util.*;

/**
 * Flat-File-Speicher auf YAML-Basis. Bewusst kein MySQL.
 * ItemStacks werden ueber Bukkits eingebaute YAML-Serialisierung abgelegt.
 */
public class DataStore {

    private final VaroPlugin plugin;
    private final File spielerDatei;
    private final File teamDatei;

    private final Map<UUID, VaroPlayer> spieler = new HashMap<>();
    private final Map<String, VaroTeam> teams = new LinkedHashMap<>();

    public DataStore(VaroPlugin plugin) {
        this.plugin = plugin;
        this.spielerDatei = new File(plugin.getDataFolder(), "spieler.yml");
        this.teamDatei = new File(plugin.getDataFolder(), "teams.yml");
    }

    // ================= Laden =================

    public void laden() {
        spieler.clear();
        teams.clear();
        ladeSpieler();
        ladeTeams();
        plugin.getLogger().info("Geladen: " + spieler.size() + " Spieler, " + teams.size() + " Teams.");
    }

    @SuppressWarnings("unchecked")
    private void ladeSpieler() {
        if (!spielerDatei.exists()) return;
        YamlConfiguration yml = YamlConfiguration.loadConfiguration(spielerDatei);
        ConfigurationSection root = yml.getConfigurationSection("spieler");
        if (root == null) return;

        for (String key : root.getKeys(false)) {
            ConfigurationSection s = root.getConfigurationSection(key);
            if (s == null) continue;
            UUID id;
            try { id = UUID.fromString(key); } catch (IllegalArgumentException e) { continue; }

            VaroPlayer vp = new VaroPlayer(id, s.getString("name", "?"));
            vp.lebt(s.getBoolean("lebt", true));
            vp.todesgrund(s.getString("todesgrund", ""));
            vp.todesZeit(s.getLong("todes-zeit", 0L));
            vp.joinsHeute(s.getInt("joins-heute", 0));
            vp.letzterTag(s.getString("letzter-tag", ""));
            vp.letztesSessionEnde(s.getLong("letztes-session-ende", 0L));
            vp.strikes(s.getInt("strikes", 0));
            vp.strikeGruende().addAll(s.getStringList("strike-gruende"));
            vp.team(s.getString("team", null));
            vp.kills(s.getInt("kills", 0));
            vp.tode(s.getInt("tode", 0));
            vp.maxHerzen(s.getDouble("max-herzen", 10.0));
            vp.letzterSpieltag(s.getString("letzter-spieltag", ""));
            vp.spielzeitSekunden(s.getLong("spielzeit", 0L));

            if (s.contains("rucksack")) {
                List<ItemStack> l = (List<ItemStack>) s.getList("rucksack");
                if (l != null) vp.rucksack(l.toArray(new ItemStack[0]));
            }
            if (s.contains("offline-inventar")) {
                List<ItemStack> l = (List<ItemStack>) s.getList("offline-inventar");
                if (l != null) vp.offlineInventar(l.toArray(new ItemStack[0]));
            }
            String oe = s.getString("offline-entity", null);
            if (oe != null && !oe.isBlank()) {
                try { vp.offlineEntity(UUID.fromString(oe)); } catch (IllegalArgumentException ignored) {}
            }
            spieler.put(id, vp);
        }
    }

    @SuppressWarnings("unchecked")
    private void ladeTeams() {
        if (!teamDatei.exists()) return;
        YamlConfiguration yml = YamlConfiguration.loadConfiguration(teamDatei);
        ConfigurationSection root = yml.getConfigurationSection("teams");
        if (root == null) return;

        for (String key : root.getKeys(false)) {
            ConfigurationSection s = root.getConfigurationSection(key);
            if (s == null) continue;
            VaroTeam t = new VaroTeam(key, s.getString("anzeigename", key));
            try {
                t.farbe(ChatColor.valueOf(s.getString("farbe", "WHITE")));
            } catch (Exception ignored) {}
            for (String m : s.getStringList("mitglieder")) {
                try { t.mitglieder().add(UUID.fromString(m)); } catch (IllegalArgumentException ignored) {}
            }
            if (s.contains("kiste")) {
                List<ItemStack> l = (List<ItemStack>) s.getList("kiste");
                if (l != null) t.kiste(l.toArray(new ItemStack[0]));
            }
            teams.put(key, t);
        }
    }

    // ================= Speichern =================

    public void speichern() {
        speichereSpieler();
        speichereTeams();
    }

    private void speichereSpieler() {
        YamlConfiguration yml = new YamlConfiguration();
        for (VaroPlayer vp : spieler.values()) {
            String p = "spieler." + vp.uuid();
            yml.set(p + ".name", vp.name());
            yml.set(p + ".lebt", vp.lebt());
            yml.set(p + ".todesgrund", vp.todesgrund());
            yml.set(p + ".todes-zeit", vp.todesZeit());
            yml.set(p + ".joins-heute", vp.joinsHeute());
            yml.set(p + ".letzter-tag", vp.letzterTag());
            yml.set(p + ".letztes-session-ende", vp.letztesSessionEnde());
            yml.set(p + ".strikes", vp.strikes());
            yml.set(p + ".strike-gruende", vp.strikeGruende());
            yml.set(p + ".team", vp.team());
            yml.set(p + ".kills", vp.kills());
            yml.set(p + ".tode", vp.tode());
            yml.set(p + ".max-herzen", vp.maxHerzen());
            yml.set(p + ".letzter-spieltag", vp.letzterSpieltag());
            yml.set(p + ".spielzeit", vp.spielzeitSekunden());
            yml.set(p + ".rucksack", vp.rucksack() == null ? null : Arrays.asList(vp.rucksack()));
            yml.set(p + ".offline-inventar", vp.offlineInventar() == null ? null : Arrays.asList(vp.offlineInventar()));
            yml.set(p + ".offline-entity", vp.offlineEntity() == null ? null : vp.offlineEntity().toString());
        }
        schreibe(yml, spielerDatei);
    }

    private void speichereTeams() {
        YamlConfiguration yml = new YamlConfiguration();
        for (VaroTeam t : teams.values()) {
            String p = "teams." + t.id();
            yml.set(p + ".anzeigename", t.anzeigename());
            yml.set(p + ".farbe", t.farbe().name());
            yml.set(p + ".mitglieder", t.mitgliederListe().stream().map(UUID::toString).toList());
            yml.set(p + ".kiste", t.kiste() == null ? null : Arrays.asList(t.kiste()));
        }
        schreibe(yml, teamDatei);
    }

    private void schreibe(YamlConfiguration yml, File datei) {
        try {
            if (!datei.getParentFile().exists()) datei.getParentFile().mkdirs();
            yml.save(datei);
        } catch (IOException e) {
            plugin.getLogger().severe("Konnte " + datei.getName() + " nicht speichern: " + e.getMessage());
        }
    }

    // ================= Zugriff =================

    public VaroPlayer get(UUID id) { return spieler.get(id); }

    public VaroPlayer getOrCreate(Player p) {
        VaroPlayer vp = spieler.computeIfAbsent(p.getUniqueId(), id -> new VaroPlayer(id, p.getName()));
        vp.name(p.getName());
        return vp;
    }

    public VaroPlayer byName(String name) {
        for (VaroPlayer vp : spieler.values()) {
            if (vp.name().equalsIgnoreCase(name)) return vp;
        }
        return null;
    }

    public Collection<VaroPlayer> alle() { return spieler.values(); }

    public List<VaroPlayer> lebende() {
        return spieler.values().stream().filter(VaroPlayer::lebt).toList();
    }

    public VaroTeam team(String id) { return id == null ? null : teams.get(id.toLowerCase()); }

    public VaroTeam teamVon(VaroPlayer vp) { return vp == null ? null : team(vp.team()); }

    public Collection<VaroTeam> teams() { return teams.values(); }

    public VaroTeam teamErstellen(String id, String anzeigename) {
        VaroTeam t = new VaroTeam(id.toLowerCase(), anzeigename);
        teams.put(t.id(), t);
        return t;
    }

    public boolean teamLoeschen(String id) {
        VaroTeam t = teams.remove(id.toLowerCase());
        if (t == null) return false;
        for (UUID m : t.mitglieder()) {
            VaroPlayer vp = spieler.get(m);
            if (vp != null) vp.team(null);
        }
        return true;
    }
}
