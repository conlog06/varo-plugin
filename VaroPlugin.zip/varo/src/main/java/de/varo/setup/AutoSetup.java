package de.varo.setup;

import de.varo.VaroPlugin;
import org.bukkit.Bukkit;
import org.bukkit.GameRule;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;

/**
 * Richtet den Server beim ersten Start (bzw. nach jedem Welt-Reset) automatisch ein:
 * Schwierigkeit, Weltgrenze, Gamerules, Spawnschutz.
 */
public class AutoSetup {

    private final VaroPlugin plugin;

    public AutoSetup(VaroPlugin plugin) {
        this.plugin = plugin;
    }

    public void ausfuehren() {
        if (!plugin.settings().autoSetup()) return;

        var s = plugin.settings();

        for (World w : Bukkit.getWorlds()) {
            w.setDifficulty(s.schwierigkeit());

            if (w.getEnvironment() == World.Environment.NORMAL && s.weltgrenze() > 0) {
                var grenze = w.getWorldBorder();
                grenze.setCenter(w.getSpawnLocation());
                grenze.setSize(s.weltgrenze());
                grenze.setWarningDistance(32);
                grenze.setDamageAmount(0.5);
            }

            wendeGamerulesAn(w);
        }

        if (s.spawnschutzAus()) {
            try {
                Bukkit.getServer().setSpawnRadius(0);
            } catch (Exception ignored) {}
        }

        plugin.getLogger().info("Auto-Setup abgeschlossen: Schwierigkeit " + s.schwierigkeit()
                + ", Weltgrenze " + (int) s.weltgrenze() + " Bloecke.");
    }

    @SuppressWarnings("unchecked")
    private void wendeGamerulesAn(World w) {
        ConfigurationSection sec = plugin.getConfig().getConfigurationSection("auto-setup.gamerules");
        if (sec == null) return;

        for (String key : sec.getKeys(false)) {
            GameRule<?> regel = GameRule.getByName(key);
            if (regel == null) {
                plugin.getLogger().warning("Unbekannte Gamerule in der Config: " + key);
                continue;
            }
            Object wert = sec.get(key);
            try {
                if (regel.getType() == Boolean.class && wert instanceof Boolean b) {
                    w.setGameRule((GameRule<Boolean>) regel, b);
                } else if (regel.getType() == Integer.class && wert instanceof Number n) {
                    w.setGameRule((GameRule<Integer>) regel, n.intValue());
                }
            } catch (Exception e) {
                plugin.getLogger().warning("Gamerule " + key + " konnte nicht gesetzt werden: " + e.getMessage());
            }
        }
    }
}
