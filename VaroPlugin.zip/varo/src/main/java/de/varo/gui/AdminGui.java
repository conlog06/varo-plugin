package de.varo.gui;

import de.varo.VaroPlugin;
import de.varo.data.VaroPlayer;
import de.varo.health.HealthManager;
import de.varo.util.TimeUtil;
import de.varo.util.Txt;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Komplettes Admin-Setup-Menü. Alle Werte werden direkt in die config.yml
 * geschrieben und wirken sofort - kein Reload nötig.
 *
 * Bedienung bei Zahlenwerten:
 *   Linksklick +1 | Shift-Linksklick +10 | Rechtsklick -1 | Shift-Rechtsklick -10
 */
public class AdminGui {

    public static final String HAUPT = "haupt";
    public static final String SESSIONS = "sessions";
    public static final String OEFFNUNG = "oeffnung";
    public static final String STRIKES = "strikes";
    public static final String TOD = "tod";
    public static final String PVP = "pvp";
    public static final String DISCORD = "discord";
    public static final String BACKUP = "backup";
    public static final String SPIELER = "spieler";
    public static final String SPIELER_DETAIL = "spielerdetail";

    private final VaroPlugin plugin;

    public AdminGui(VaroPlugin plugin) {
        this.plugin = plugin;
    }

    // ==================================================================
    //  Öffnen
    // ==================================================================

    public void oeffne(Player p, String menue, String kontext) {
        Inventory inv = switch (menue) {
            case SESSIONS -> baueSessions();
            case OEFFNUNG -> baueOeffnung();
            case STRIKES -> baueStrikes();
            case TOD -> baueTod();
            case PVP -> bauePvp();
            case DISCORD -> baueDiscord();
            case BACKUP -> baueBackup();
            case SPIELER -> baueSpieler();
            case SPIELER_DETAIL -> baueSpielerDetail(kontext);
            default -> baueHaupt();
        };
        if (inv == null) {
            p.sendMessage(Txt.c(plugin.messages().praefix() + "&cMenü konnte nicht geöffnet werden."));
            return;
        }
        p.openInventory(inv);
    }

    public void oeffneHaupt(Player p) {
        oeffne(p, HAUPT, "");
    }

    private Inventory erstelle(String menue, String kontext, int groesse, String titel) {
        GuiHolder holder = new GuiHolder(menue, kontext);
        Inventory inv = Bukkit.createInventory(holder, groesse, name(titel));
        holder.setInventory(inv);
        rahmen(inv);
        return inv;
    }

    // ==================================================================
    //  Menüaufbau
    // ==================================================================

    private Inventory baueHaupt() {
        Inventory inv = erstelle(HAUPT, "", 45, "&8» &6Varo Admin-Setup");

        boolean laeuft = plugin.settings().laeuft();
        inv.setItem(4, item(laeuft ? Material.BEACON : Material.REDSTONE_BLOCK,
                "&6&lProjekt: " + (laeuft ? "&aLÄUFT" : "&cPAUSIERT"),
                "&7Tag &f" + plugin.dayManager().projektTag()
                        + " &8| &7Season &f" + plugin.settings().season(),
                "&7Am Leben: &f" + plugin.data().lebende().size()
                        + "&7/&f" + plugin.data().alle().size(),
                "",
                "&eKlick: " + (laeuft ? "pausieren" : "fortsetzen")));

        inv.setItem(10, item(Material.CLOCK, "&e&lSessions",
                "&7Joins pro Tag: &f" + plugin.settings().joinsProTag(),
                "&7Dauer: &f" + plugin.settings().sessionMinuten() + " min",
                "&7Pause: &f" + plugin.settings().abklingzeitMinuten() + " min"));

        inv.setItem(12, item(Material.DAYLIGHT_DETECTOR, "&e&lServer-Öffnungszeiten",
                "&7Von &f" + plugin.settings().oeffnetText()
                        + " &7bis &f" + plugin.settings().schliesstText() + " &7Uhr",
                "&7Status: " + (plugin.oeffnungszeiten().offen() ? "&aoffen" : "&cgeschlossen")));

        inv.setItem(14, item(Material.PAPER, "&e&lStrikes",
                "&7Maximum: &f" + plugin.settings().strikeMaximum(),
                "&7Inaktivität: " + anAus(plugin.settings().inaktivitaetAktiv())));

        inv.setItem(16, item(Material.TOTEM_OF_UNDYING, "&e&lTod & Herzen",
                "&7Modus: &f" + plugin.settings().todModus(),
                "&7Verlust pro Tod: &c" + HealthManager.format(plugin.settings().herzverlust()) + " ♥",
                "&7Welt-Reset: " + anAus(plugin.settings().weltReset())));

        inv.setItem(28, item(Material.DIAMOND_SWORD, "&e&lPvP",
                "&7PvP: " + anAus(plugin.settings().pvpAktiv()),
                "&7Automatisch ab Tag: &f"
                        + (plugin.settings().pvpAbTag() > 0 ? plugin.settings().pvpAbTag() : "nie")));

        inv.setItem(30, item(Material.ENDER_PEARL, "&e&lDiscord",
                "&7Webhook: " + anAus(plugin.settings().discordAktiv()),
                "&8URL nur in der config.yml änderbar"));

        inv.setItem(32, item(Material.CHEST, "&e&lBackups",
                "&7Automatik: " + anAus(plugin.settings().backupAktiv()),
                "&7Intervall: &f" + plugin.settings().backupIntervall() + " min"));

        inv.setItem(34, kopf(null, "&e&lSpielerverwaltung",
                "&7Strikes, Herzen, Wiederbeleben",
                "&7" + plugin.data().alle().size() + " Spieler erfasst"));

        inv.setItem(40, item(Material.BARRIER, "&c&lSchließen"));
        return inv;
    }

    private Inventory baueSessions() {
        Inventory inv = erstelle(SESSIONS, "", 27, "&8» &6Sessions");

        inv.setItem(10, zahl(Material.CLOCK, "&e&lJoins pro Tag",
                plugin.settings().joinsProTag(), ""));
        inv.setItem(12, zahl(Material.COMPASS, "&e&lSessiondauer",
                plugin.settings().sessionMinuten(), " Minuten"));
        inv.setItem(14, zahl(Material.HOPPER, "&e&lPause zwischen Sessions",
                plugin.settings().abklingzeitMinuten(), " Minuten"));
        inv.setItem(16, item(plugin.settings().actionbar() ? Material.LIME_DYE : Material.GRAY_DYE,
                "&e&lActionbar-Timer", "&7Status: " + anAus(plugin.settings().actionbar()),
                "", "&eKlick zum Umschalten"));

        inv.setItem(22, zurueck());
        return inv;
    }

    private Inventory baueOeffnung() {
        Inventory inv = erstelle(OEFFNUNG, "", 27, "&8» &6Öffnungszeiten");

        inv.setItem(4, item(plugin.settings().oeffnungAktiv() ? Material.LIME_DYE : Material.GRAY_DYE,
                "&e&lZeitfenster aktiv", "&7Status: " + anAus(plugin.settings().oeffnungAktiv()),
                "", "&eKlick zum Umschalten"));

        inv.setItem(10, zahl(Material.SUNFLOWER, "&e&lÖffnet — Stunde",
                plugin.settings().oeffnetStunde(), " Uhr"));
        inv.setItem(11, zahl(Material.SUNFLOWER, "&e&lÖffnet — Minute",
                plugin.settings().oeffnetMinute(), ""));

        inv.setItem(14, zahl(Material.CLOCK, "&e&lSchließt — Stunde",
                plugin.settings().schliesstStunde(), " Uhr"));
        inv.setItem(15, zahl(Material.CLOCK, "&e&lSchließt — Minute",
                plugin.settings().schliesstMinute(), ""));

        inv.setItem(13, item(Material.BOOK, "&7Aktuell",
                "&7Fenster: &f" + plugin.settings().oeffnetText()
                        + " &7- &f" + plugin.settings().schliesstText(),
                "&7Status: " + (plugin.oeffnungszeiten().offen() ? "&aoffen" : "&cgeschlossen"),
                plugin.oeffnungszeiten().offen()
                        ? "&7Schließt in &f" + TimeUtil.humanDe(plugin.oeffnungszeiten().sekundenBisSchluss())
                        : "&7Öffnet in &f" + TimeUtil.humanDe(plugin.oeffnungszeiten().sekundenBisOeffnung())));

        inv.setItem(22, zurueck());
        return inv;
    }

    private Inventory baueStrikes() {
        Inventory inv = erstelle(STRIKES, "", 27, "&8» &6Strikes");

        inv.setItem(10, item(plugin.settings().strikesAktiv() ? Material.LIME_DYE : Material.GRAY_DYE,
                "&e&lStrike-System", "&7Status: " + anAus(plugin.settings().strikesAktiv()),
                "", "&eKlick zum Umschalten"));

        inv.setItem(12, zahl(Material.PAPER, "&e&lMaximum",
                plugin.settings().strikeMaximum(), " Strikes bis Aus"));

        inv.setItem(14, item(plugin.settings().inaktivitaetAktiv() ? Material.LIME_DYE : Material.GRAY_DYE,
                "&e&lStrike bei Inaktivität",
                "&7Wer einen ganzen Tag nicht online war,",
                "&7bekommt automatisch einen Strike.",
                "&7Status: " + anAus(plugin.settings().inaktivitaetAktiv()),
                "", "&eKlick zum Umschalten"));

        inv.setItem(16, zahl(Material.BOOK, "&e&lErst ab Projekttag",
                plugin.settings().inaktivitaetAbTag(), ""));

        inv.setItem(22, zurueck());
        return inv;
    }

    private Inventory baueTod() {
        Inventory inv = erstelle(TOD, "", 36, "&8» &6Tod & Herzen");

        boolean herz = plugin.settings().herzverlustModus();
        inv.setItem(10, item(herz ? Material.RED_DYE : Material.SKELETON_SKULL, "&e&lModus",
                "&7Aktuell: &f" + plugin.settings().todModus(),
                "",
                herz ? "&8HERZVERLUST: Spieler verliert Herzen"
                     : "&8AUSSCHEIDEN: Spieler ist sofort raus",
                "", "&eKlick zum Umschalten"));

        inv.setItem(12, komma(Material.REDSTONE, "&e&lHerzverlust pro Tod",
                plugin.settings().herzverlust(), " ♥"));

        inv.setItem(14, komma(Material.GOLDEN_APPLE, "&e&lStart-Herzen",
                plugin.settings().startHerzen(), " ♥"));

        inv.setItem(16, komma(Material.BARRIER, "&e&lAus bei Herzen ≤",
                plugin.settings().minimumHerzen(), " ♥"));

        inv.setItem(20, item(plugin.settings().weltReset() ? Material.LIME_DYE : Material.GRAY_DYE,
                "&e&lWelt-Reset bei Tod",
                "&7Backup, Serverstopp, neue Welten.",
                "&7Status: " + anAus(plugin.settings().weltReset()),
                "", "&eKlick zum Umschalten"));

        inv.setItem(22, zahl(Material.CLOCK, "&e&lReset-Countdown",
                plugin.settings().resetCountdown(), " Sekunden"));

        inv.setItem(24, item(plugin.settings().herzenBehalten() ? Material.LIME_DYE : Material.GRAY_DYE,
                "&e&lHerzen über Reset behalten",
                "&7Status: " + anAus(plugin.settings().herzenBehalten()),
                "", "&eKlick zum Umschalten"));

        inv.setItem(31, zurueck());
        return inv;
    }

    private Inventory bauePvp() {
        Inventory inv = erstelle(PVP, "", 27, "&8» &6PvP");

        inv.setItem(11, item(plugin.settings().pvpAktiv() ? Material.DIAMOND_SWORD : Material.WOODEN_SWORD,
                "&e&lPvP", "&7Status: " + anAus(plugin.settings().pvpAktiv()),
                "&8Aus = Spieler können sich nicht verletzen",
                "", "&eKlick zum Umschalten"));

        inv.setItem(13, zahl(Material.BOOK, "&e&lPvP automatisch ab Tag",
                plugin.settings().pvpAbTag(), " (0 = nie)"));

        inv.setItem(15, zahl(Material.SHIELD, "&e&lKampf-Tag Dauer",
                plugin.settings().kampfTagSekunden(), " Sekunden"));

        inv.setItem(22, zurueck());
        return inv;
    }

    private Inventory baueDiscord() {
        Inventory inv = erstelle(DISCORD, "", 27, "&8» &6Discord");

        inv.setItem(10, item(plugin.settings().discordAktiv() ? Material.LIME_DYE : Material.GRAY_DYE,
                "&e&lWebhook aktiv", "&7Status: " + anAus(plugin.settings().discordAktiv()),
                "&8URL wird in der config.yml gesetzt", "", "&eKlick zum Umschalten"));

        inv.setItem(12, toggleItem("&e&lMeldung bei Tod", plugin.settings().discordBeiTod()));
        inv.setItem(13, toggleItem("&e&lMeldung bei Strike", plugin.settings().discordBeiStrike()));
        inv.setItem(14, toggleItem("&e&lMeldung bei Strafe/Herzverlust", plugin.settings().discordBeiStrafe()));
        inv.setItem(15, toggleItem("&e&lMeldung bei Welt-Reset", plugin.settings().discordBeiReset()));
        inv.setItem(16, toggleItem("&e&lMeldung bei Join/Quit", plugin.settings().discordBeiJoinQuit()));

        inv.setItem(21, item(Material.PAPER, "&a&lTestnachricht senden",
                "&7Schickt eine Testmeldung an den Webhook."));

        inv.setItem(22, zurueck());
        return inv;
    }

    private Inventory baueBackup() {
        Inventory inv = erstelle(BACKUP, "", 27, "&8» &6Backups");

        inv.setItem(10, item(plugin.settings().backupAktiv() ? Material.LIME_DYE : Material.GRAY_DYE,
                "&e&lAutomatische Backups", "&7Status: " + anAus(plugin.settings().backupAktiv()),
                "&8Änderung wirkt beim nächsten Serverstart", "", "&eKlick zum Umschalten"));

        inv.setItem(12, zahl(Material.CLOCK, "&e&lIntervall",
                plugin.settings().backupIntervall(), " Minuten"));

        inv.setItem(14, zahl(Material.CHEST, "&e&lMaximal aufheben",
                plugin.settings().maxBackups(), " Backups"));

        inv.setItem(16, item(Material.ENDER_CHEST, "&a&lJetzt sichern",
                "&7Erstellt sofort ein Backup.",
                "&7Ordner: &f" + plugin.settings().backupOrdner()));

        inv.setItem(22, zurueck());
        return inv;
    }

    private Inventory baueSpieler() {
        Inventory inv = erstelle(SPIELER, "", 54, "&8» &6Spielerverwaltung");

        List<Integer> slots = spielerSlots();
        int index = 0;
        for (VaroPlayer vp : plugin.data().alle()) {
            if (index >= slots.size()) break;
            int slot = slots.get(index++);

            List<String> lore = new ArrayList<>();
            lore.add("&7Status: " + (vp.lebt() ? "&aam Leben" : "&causgeschieden"));
            if (!vp.lebt()) lore.add("&8Grund: " + vp.todesgrund());
            lore.add("&7Herzen: &c" + HealthManager.format(vp.maxHerzen()) + " ♥");
            lore.add("&7Strikes: &f" + vp.strikes() + "&7/&f" + plugin.settings().strikeMaximum());
            lore.add("&7Joins heute: &f" + vp.joinsHeute() + "&7/&f" + plugin.settings().joinsProTag());
            lore.add("&7Tode: &f" + vp.tode() + " &8| &7Kills: &f" + vp.kills());
            lore.add("");
            lore.add("&eKlick zum Verwalten");

            inv.setItem(slot, kopf(vp.uuid(),
                    (vp.lebt() ? "&a" : "&8") + vp.name(), lore.toArray(new String[0])));
        }

        inv.setItem(49, zurueck());
        return inv;
    }

    private Inventory baueSpielerDetail(String kontext) {
        VaroPlayer vp = spieler(kontext);
        if (vp == null) return null;

        Inventory inv = erstelle(SPIELER_DETAIL, kontext, 36, "&8» &6" + vp.name());

        inv.setItem(4, kopf(vp.uuid(), "&6&l" + vp.name(),
                "&7Status: " + (vp.lebt() ? "&aam Leben" : "&causgeschieden"),
                "&7Herzen: &c" + HealthManager.format(vp.maxHerzen()) + " ♥",
                "&7Strikes: &f" + vp.strikes() + "&7/&f" + plugin.settings().strikeMaximum(),
                "&7Spielzeit: &f" + TimeUtil.humanDe(vp.spielzeitSekunden())));

        inv.setItem(10, item(Material.RED_DYE, "&c&lStrike geben",
                "&7Aktuell: &f" + vp.strikes() + "&7/&f" + plugin.settings().strikeMaximum(),
                "", "&eKlick: +1 Strike"));

        inv.setItem(11, item(Material.LIME_DYE, "&a&lStrike zurücknehmen",
                "&7Nimmt den letzten Strike zurück.",
                "", "&eKlick: -1 Strike"));

        inv.setItem(13, item(Material.GOLDEN_APPLE, "&e&lHerzen",
                "&7Aktuell: &c" + HealthManager.format(vp.maxHerzen()) + " ♥",
                "",
                "&8Linksklick &7+0,5 ♥ &8| &8Shift &7+2 ♥",
                "&8Rechtsklick &7-0,5 ♥ &8| &8Shift &7-2 ♥"));

        inv.setItem(15, item(Material.CLOCK, "&e&lJoins zurücksetzen",
                "&7Heute: &f" + vp.joinsHeute() + "&7/&f" + plugin.settings().joinsProTag(),
                "", "&eKlick: auf 0 setzen"));

        inv.setItem(16, item(vp.lebt() ? Material.SKELETON_SKULL : Material.TOTEM_OF_UNDYING,
                vp.lebt() ? "&c&lAusscheiden lassen" : "&a&lWiederbeleben",
                vp.lebt() ? "&7Setzt den Spieler auf ausgeschieden."
                          : "&7Holt den Spieler zurück ins Projekt.",
                "", "&eKlick zum Bestätigen"));

        if (!vp.strikeGruende().isEmpty()) {
            List<String> lore = new ArrayList<>();
            int von = Math.max(0, vp.strikeGruende().size() - 8);
            for (int i = von; i < vp.strikeGruende().size(); i++) {
                lore.add("&8" + (i + 1) + ". &7" + vp.strikeGruende().get(i));
            }
            inv.setItem(22, item(Material.WRITABLE_BOOK, "&e&lStrike-Verlauf", lore.toArray(new String[0])));
        }

        inv.setItem(31, item(Material.ARROW, "&7&lZurück zur Spielerliste"));
        return inv;
    }

    // ==================================================================
    //  Klickverarbeitung
    // ==================================================================

    public void klick(Player p, String menue, String kontext, int slot, ClickType typ) {
        boolean geaendert = true;

        switch (menue) {
            case HAUPT -> {
                switch (slot) {
                    case 4 -> {
                        boolean neu = !plugin.settings().laeuft();
                        plugin.settings().laeuft(neu);
                        Bukkit.broadcast(Txt.c(plugin.messages().praefix()
                                + (neu ? "&aDas Projekt läuft wieder." : "&eDas Projekt wurde &cpausiert&e.")));
                    }
                    case 10 -> { oeffne(p, SESSIONS, ""); return; }
                    case 12 -> { oeffne(p, OEFFNUNG, ""); return; }
                    case 14 -> { oeffne(p, STRIKES, ""); return; }
                    case 16 -> { oeffne(p, TOD, ""); return; }
                    case 28 -> { oeffne(p, PVP, ""); return; }
                    case 30 -> { oeffne(p, DISCORD, ""); return; }
                    case 32 -> { oeffne(p, BACKUP, ""); return; }
                    case 34 -> { oeffne(p, SPIELER, ""); return; }
                    case 40 -> { p.closeInventory(); return; }
                    default -> geaendert = false;
                }
            }

            case SESSIONS -> {
                switch (slot) {
                    case 10 -> plugin.settings().joinsProTag(
                            plugin.settings().joinsProTag() + delta(typ, 1, 5));
                    case 12 -> {
                        plugin.settings().sessionMinuten(
                                plugin.settings().sessionMinuten() + delta(typ, 5, 30));
                        plugin.sessionManager().alleSessionsNeuBerechnen();
                    }
                    case 14 -> plugin.settings().abklingzeitMinuten(
                            plugin.settings().abklingzeitMinuten() + delta(typ, 5, 30));
                    case 16 -> plugin.settings().toggle("session.actionbar", true);
                    case 22 -> { oeffne(p, HAUPT, ""); return; }
                    default -> geaendert = false;
                }
            }

            case OEFFNUNG -> {
                switch (slot) {
                    case 4 -> plugin.settings().toggle("oeffnungszeiten.aktiv", true);
                    case 10 -> plugin.settings().set("oeffnungszeiten.oeffnet-stunde",
                            wrap(plugin.settings().oeffnetStunde() + delta(typ, 1, 6), 24));
                    case 11 -> plugin.settings().set("oeffnungszeiten.oeffnet-minute",
                            wrap(plugin.settings().oeffnetMinute() + delta(typ, 1, 15), 60));
                    case 14 -> plugin.settings().set("oeffnungszeiten.schliesst-stunde",
                            wrap(plugin.settings().schliesstStunde() + delta(typ, 1, 6), 24));
                    case 15 -> plugin.settings().set("oeffnungszeiten.schliesst-minute",
                            wrap(plugin.settings().schliesstMinute() + delta(typ, 1, 15), 60));
                    case 22 -> { oeffne(p, HAUPT, ""); return; }
                    default -> geaendert = false;
                }
            }

            case STRIKES -> {
                switch (slot) {
                    case 10 -> plugin.settings().toggle("strikes.aktiv", true);
                    case 12 -> plugin.settings().set("strikes.maximum",
                            Math.max(1, plugin.settings().strikeMaximum() + delta(typ, 1, 5)));
                    case 14 -> plugin.settings().toggle("strikes.inaktivitaet-aktiv", true);
                    case 16 -> plugin.settings().set("strikes.inaktivitaet-ab-tag",
                            Math.max(1, plugin.settings().inaktivitaetAbTag() + delta(typ, 1, 5)));
                    case 22 -> { oeffne(p, HAUPT, ""); return; }
                    default -> geaendert = false;
                }
            }

            case TOD -> {
                switch (slot) {
                    case 10 -> plugin.settings().set("tod.modus",
                            plugin.settings().herzverlustModus() ? "AUSSCHEIDEN" : "HERZVERLUST");
                    case 12 -> plugin.settings().set("tod.herzverlust",
                            Math.max(0.5, plugin.settings().herzverlust() + deltaKomma(typ)));
                    case 14 -> plugin.settings().set("tod.start-herzen",
                            Math.max(0.5, plugin.settings().startHerzen() + deltaKomma(typ)));
                    case 16 -> plugin.settings().set("tod.minimum-herzen",
                            Math.max(0.0, plugin.settings().minimumHerzen() + deltaKomma(typ)));
                    case 20 -> plugin.settings().toggle("tod.welt-reset", true);
                    case 22 -> plugin.settings().set("tod.countdown-sekunden",
                            Math.max(5, plugin.settings().resetCountdown() + delta(typ, 5, 30)));
                    case 24 -> plugin.settings().toggle("tod.herzen-behalten", true);
                    case 31 -> { oeffne(p, HAUPT, ""); return; }
                    default -> geaendert = false;
                }
            }

            case PVP -> {
                switch (slot) {
                    case 11 -> plugin.settings().toggle("pvp.aktiv", false);
                    case 13 -> plugin.settings().set("pvp.ab-tag",
                            Math.max(0, plugin.settings().pvpAbTag() + delta(typ, 1, 5)));
                    case 15 -> plugin.settings().set("kampf-tag.dauer-sekunden",
                            Math.max(1, plugin.settings().kampfTagSekunden() + delta(typ, 1, 10)));
                    case 22 -> { oeffne(p, HAUPT, ""); return; }
                    default -> geaendert = false;
                }
            }

            case DISCORD -> {
                switch (slot) {
                    case 10 -> plugin.settings().toggle("discord.aktiv", false);
                    case 12 -> plugin.settings().toggle("discord.bei-tod", true);
                    case 13 -> plugin.settings().toggle("discord.bei-strike", true);
                    case 14 -> plugin.settings().toggle("discord.bei-strafe", true);
                    case 15 -> plugin.settings().toggle("discord.bei-welt-reset", true);
                    case 16 -> plugin.settings().toggle("discord.bei-join-quit", false);
                    case 21 -> {
                        plugin.discord().sende("🔧 Testnachricht von **" + p.getName() + "** — "
                                + "Webhook funktioniert.");
                        p.sendMessage(Txt.c(plugin.messages().praefix()
                                + "&7Testnachricht abgeschickt. Prüf den Discord-Kanal."));
                    }
                    case 22 -> { oeffne(p, HAUPT, ""); return; }
                    default -> geaendert = false;
                }
            }

            case BACKUP -> {
                switch (slot) {
                    case 10 -> plugin.settings().toggle("backup.aktiv", true);
                    case 12 -> plugin.settings().set("backup.intervall-minuten",
                            Math.max(0, plugin.settings().backupIntervall() + delta(typ, 15, 60)));
                    case 14 -> plugin.settings().set("backup.max-backups",
                            Math.max(0, plugin.settings().maxBackups() + delta(typ, 1, 5)));
                    case 16 -> {
                        p.closeInventory();
                        p.sendMessage(Txt.c(plugin.messages().praefix() + "&7Backup wird erstellt..."));
                        plugin.backup().weltenSpeichern();
                        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
                            var pfad = plugin.backup().erstelleBackup("manuell");
                            Bukkit.getScheduler().runTask(plugin, () -> p.sendMessage(Txt.c(
                                    plugin.messages().praefix() + (pfad != null
                                            ? "&aBackup erstellt: &f" + pfad.getFileName()
                                            : "&cBackup fehlgeschlagen - siehe Konsole."))));
                        });
                        return;
                    }
                    case 22 -> { oeffne(p, HAUPT, ""); return; }
                    default -> geaendert = false;
                }
            }

            case SPIELER -> {
                if (slot == 49) { oeffne(p, HAUPT, ""); return; }
                VaroPlayer ziel = spielerAusSlot(slot);
                if (ziel != null) {
                    oeffne(p, SPIELER_DETAIL, ziel.uuid().toString());
                    return;
                }
                geaendert = false;
            }

            case SPIELER_DETAIL -> {
                VaroPlayer vp = spieler(kontext);
                if (vp == null) { oeffne(p, SPIELER, ""); return; }

                switch (slot) {
                    case 10 -> plugin.strikes().strikeGeben(vp, "manuell im Admin-Menü", p.getName());
                    case 11 -> {
                        if (plugin.strikes().strikeEntfernen(vp)) {
                            Player online = Bukkit.getPlayer(vp.uuid());
                            if (online != null) {
                                online.sendMessage(plugin.messages().chat("strike-entfernt",
                                        "anzahl", vp.strikes(), "max", plugin.settings().strikeMaximum()));
                            }
                            if (plugin.settings().discordAktiv() && plugin.settings().discordBeiStrike()) {
                                plugin.discord().sende("↩ Strike von **" + vp.name()
                                        + "** zurückgenommen durch " + p.getName()
                                        + " (" + vp.strikes() + "/" + plugin.settings().strikeMaximum() + ")");
                            }
                        }
                    }
                    case 13 -> plugin.health().setzeHerzen(vp, vp.maxHerzen() + deltaKomma(typ));
                    case 15 -> {
                        vp.joinsHeute(0);
                        vp.letzterTag(plugin.dayManager().heute().toString());
                        plugin.data().speichern();
                    }
                    case 16 -> {
                        if (vp.lebt()) {
                            p.closeInventory();
                            plugin.deathManager().spielerAusscheiden(vp, "durch Admin ausgeschieden");
                            return;
                        }
                        vp.lebt(true);
                        vp.todesgrund("");
                        vp.todesZeit(0);
                        if (vp.maxHerzen() <= plugin.settings().minimumHerzen()) {
                            vp.maxHerzen(plugin.settings().startHerzen());
                        }
                        plugin.data().speichern();
                        Player online = Bukkit.getPlayer(vp.uuid());
                        if (online != null) {
                            online.setGameMode(org.bukkit.GameMode.SURVIVAL);
                            plugin.health().anwenden(online);
                        }
                        Bukkit.broadcast(Txt.c(plugin.messages().praefix()
                                + "&a" + vp.name() + " wurde wiederbelebt."));
                    }
                    case 31 -> { oeffne(p, SPIELER, ""); return; }
                    default -> geaendert = false;
                }
            }

            default -> geaendert = false;
        }

        if (geaendert) {
            p.playSound(p.getLocation(), Sound.UI_BUTTON_CLICK, 0.5f, 1.4f);
            oeffne(p, menue, kontext);
        }
    }

    // ==================================================================
    //  Hilfsmittel
    // ==================================================================

    private int delta(ClickType typ, int klein, int gross) {
        int betrag = typ.isShiftClick() ? gross : klein;
        return typ.isRightClick() ? -betrag : betrag;
    }

    private double deltaKomma(ClickType typ) {
        double betrag = typ.isShiftClick() ? 2.0 : 0.5;
        return typ.isRightClick() ? -betrag : betrag;
    }

    /** Hält Stunden/Minuten im gültigen Bereich (0..grenze-1). */
    private int wrap(int wert, int grenze) {
        int w = wert % grenze;
        return w < 0 ? w + grenze : w;
    }

    private VaroPlayer spieler(String uuidString) {
        try {
            return plugin.data().get(UUID.fromString(uuidString));
        } catch (Exception e) {
            return null;
        }
    }

    /** Innenflaeche eines 54er-Inventars, Zeile fuer Zeile. */
    private List<Integer> spielerSlots() {
        List<Integer> slots = new ArrayList<>();
        for (int zeile = 1; zeile <= 3; zeile++) {
            for (int spalte = 1; spalte <= 7; spalte++) {
                slots.add(zeile * 9 + spalte);
            }
        }
        return slots;
    }

    private VaroPlayer spielerAusSlot(int slot) {
        List<Integer> slots = spielerSlots();
        int index = slots.indexOf(slot);
        if (index < 0) return null;
        List<VaroPlayer> alle = new ArrayList<>(plugin.data().alle());
        return index < alle.size() ? alle.get(index) : null;
    }

    private String anAus(boolean b) {
        return b ? "&aan" : "&caus";
    }

    private Component name(String s) {
        return Txt.c(s).decoration(TextDecoration.ITALIC, false);
    }

    private ItemStack item(Material material, String titel, String... lore) {
        ItemStack is = new ItemStack(material);
        ItemMeta meta = is.getItemMeta();
        if (meta != null) {
            meta.displayName(name(titel));
            if (lore.length > 0) {
                List<Component> l = new ArrayList<>();
                for (String zeile : lore) l.add(name(zeile));
                meta.lore(l);
            }
            is.setItemMeta(meta);
        }
        return is;
    }

    private ItemStack zahl(Material material, String titel, int wert, String einheit) {
        return item(material, titel,
                "&7Aktuell: &f" + wert + einheit,
                "",
                "&8Linksklick &7+ &8| &8Shift-Links &7++",
                "&8Rechtsklick &7- &8| &8Shift-Rechts &7--");
    }

    private ItemStack komma(Material material, String titel, double wert, String einheit) {
        return item(material, titel,
                "&7Aktuell: &f" + HealthManager.format(wert) + einheit,
                "",
                "&8Linksklick &7+0,5 &8| &8Shift-Links &7+2",
                "&8Rechtsklick &7-0,5 &8| &8Shift-Rechts &7-2");
    }

    private ItemStack toggleItem(String titel, boolean zustand) {
        return item(zustand ? Material.LIME_DYE : Material.GRAY_DYE, titel,
                "&7Status: " + anAus(zustand), "", "&eKlick zum Umschalten");
    }

    private ItemStack zurueck() {
        return item(Material.ARROW, "&7&lZurück");
    }

    private ItemStack kopf(UUID besitzer, String titel, String... lore) {
        ItemStack is = new ItemStack(Material.PLAYER_HEAD);
        if (is.getItemMeta() instanceof SkullMeta meta) {
            if (besitzer != null) {
                meta.setOwningPlayer(Bukkit.getOfflinePlayer(besitzer));
            }
            meta.displayName(name(titel));
            if (lore.length > 0) {
                List<Component> l = new ArrayList<>();
                for (String zeile : lore) l.add(name(zeile));
                meta.lore(l);
            }
            is.setItemMeta(meta);
        }
        return is;
    }

    /** Grauer Rahmen für optische Ruhe. */
    private void rahmen(Inventory inv) {
        ItemStack fueller = item(Material.GRAY_STAINED_GLASS_PANE, "&r");
        int groesse = inv.getSize();
        for (int i = 0; i < groesse; i++) {
            boolean randOben = i < 9;
            boolean randUnten = i >= groesse - 9;
            boolean randLinks = i % 9 == 0;
            boolean randRechts = i % 9 == 8;
            if (randOben || randUnten || randLinks || randRechts) {
                inv.setItem(i, fueller);
            }
        }
    }
}
