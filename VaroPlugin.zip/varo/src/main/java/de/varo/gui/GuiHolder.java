package de.varo.gui;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.jetbrains.annotations.NotNull;

/** Markiert ein Admin-Menue, damit der Listener Klicks zuordnen kann. */
public class GuiHolder implements InventoryHolder {

    private final String menue;
    private final String kontext;
    private Inventory inventory;

    public GuiHolder(String menue, String kontext) {
        this.menue = menue;
        this.kontext = kontext;
    }

    public String menue() { return menue; }
    public String kontext() { return kontext; }

    public void setInventory(Inventory inv) { this.inventory = inv; }

    @Override
    public @NotNull Inventory getInventory() { return inventory; }
}
