package de.varo.health;

import de.varo.VaroPlugin;
import de.varo.data.VaroPlayer;
import de.varo.util.Txt;
import org.bukkit.Bukkit;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.Player;

/**
 * Dauerhafter Herzverlust pro Tod (CraftAttack-Style).
 * Die Herzen liegen als Wert in den Spielerdaten und werden bei jedem Join
 * als MAX_HEALTH-Attribut auf den Spieler angewendet.
 */
public class HealthManager {

    private final VaroPlugin plugin;

    public HealthManager(VaroPlugin plugin) {
        this.plugin = plugin;
    }

    /** Setzt die maximale Gesundheit gemaess Spielerdaten. */
    public void anwenden(Player p) {
        VaroPlayer vp = plugin.data().getOrCreate(p);

        if (vp.maxHerzen() <= 0) {
            vp.maxHerzen(plugin.settings().startHerzen());
        }

        double hp = Math.max(1.0, vp.maxHerzen() * 2.0);
        var attr = p.getAttribute(Attribute.MAX_HEALTH);
        if (attr == null) return;

        attr.setBaseValue(hp);
        if (p.getHealth() > hp) p.setHealth(hp);
    }

    /**
     * Zieht den konfigurierten Betrag ab.
     * @return true, wenn der Spieler dadurch ausscheidet
     */
    public boolean herzAbziehen(VaroPlayer vp, String grund) {
        double verlust = plugin.settings().herzverlust();
        double neu = Math.max(0.0, vp.maxHerzen() - verlust);
        vp.maxHerzen(neu);
        vp.tode(vp.tode() + 1);
        plugin.data().speichern();

        Bukkit.broadcast(plugin.messages().chat("herzverlust-broadcast",
                "spieler", vp.name(), "grund", grund, "herzen", format(neu)));

        Player online = Bukkit.getPlayer(vp.uuid());
        if (online != null) {
            online.sendMessage(plugin.messages().chat("herzverlust",
                    "verlust", format(verlust), "herzen", format(neu)));
            anwenden(online);
        }

        if (plugin.settings().discordAktiv() && plugin.settings().discordBeiStrafe()) {
            plugin.discord().sende("♥ **" + vp.name() + "** ist gestorben (" + grund + ") — "
                    + "**-" + format(verlust) + " Herzen**, verbleibend: **" + format(neu) + " ♥**"
                    + "\n*Tod Nr. " + vp.tode() + " • Tag " + plugin.dayManager().projektTag() + "*");
        }

        if (neu <= plugin.settings().minimumHerzen()) {
            Bukkit.broadcast(plugin.messages().chat("keine-herzen-mehr", "spieler", vp.name()));
            return true;
        }
        return false;
    }

    /** Herzen manuell setzen (Admin-GUI). */
    public void setzeHerzen(VaroPlayer vp, double herzen) {
        vp.maxHerzen(Math.max(0.5, herzen));
        plugin.data().speichern();
        Player online = Bukkit.getPlayer(vp.uuid());
        if (online != null) {
            anwenden(online);
            online.sendMessage(Txt.c(plugin.messages().praefix()
                    + "&7Deine Herzen wurden auf &c" + format(vp.maxHerzen()) + " ♥ &7gesetzt."));
        }
    }

    public static String format(double herzen) {
        return herzen == Math.floor(herzen)
                ? String.valueOf((int) herzen)
                : String.format(java.util.Locale.GERMANY, "%.1f", herzen);
    }
}
