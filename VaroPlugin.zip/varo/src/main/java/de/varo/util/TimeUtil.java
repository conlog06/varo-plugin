package de.varo.util;

import java.time.Duration;

public final class TimeUtil {

    private TimeUtil() {}

    /** 3725 -> "1:02:05", 125 -> "02:05" */
    public static String format(long sekunden) {
        if (sekunden < 0) sekunden = 0;
        long h = sekunden / 3600;
        long m = (sekunden % 3600) / 60;
        long s = sekunden % 60;
        if (h > 0) return String.format("%d:%02d:%02d", h, m, s);
        return String.format("%02d:%02d", m, s);
    }

    /** 3725 -> "1h 2m", 125 -> "2m 5s" */
    public static String humanDe(long sekunden) {
        if (sekunden <= 0) return "0s";
        long h = sekunden / 3600;
        long m = (sekunden % 3600) / 60;
        long s = sekunden % 60;
        StringBuilder sb = new StringBuilder();
        if (h > 0) sb.append(h).append("h ");
        if (m > 0) sb.append(m).append("m ");
        if (h == 0 && s > 0) sb.append(s).append("s");
        return sb.toString().trim();
    }

    public static String format(Duration d) {
        return format(d.getSeconds());
    }
}
