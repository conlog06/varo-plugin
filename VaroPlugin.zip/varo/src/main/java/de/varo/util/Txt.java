package de.varo.util;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;

/** Kleiner Helfer, damit im Code und in den Configs weiterhin '&'-Farbcodes benutzt werden koennen. */
public final class Txt {

    private static final LegacyComponentSerializer SER = LegacyComponentSerializer.builder()
            .character('&')
            .hexCharacter('#')
            .hexColors()
            .build();

    private Txt() {}

    public static Component c(String legacy) {
        if (legacy == null) return Component.empty();
        // ChatColor.toString() liefert Paragraphzeichen - hier auf & normalisieren
        return SER.deserialize(legacy.replace('\u00A7', '&'));
    }

    public static String plain(Component component) {
        return SER.serialize(component);
    }

    /** Ersetzt Platzhalter im Format {schluessel}. Erwartet Paare: key1, wert1, key2, wert2, ... */
    public static String fill(String text, Object... pairs) {
        if (text == null) return "";
        String out = text;
        for (int i = 0; i + 1 < pairs.length; i += 2) {
            out = out.replace("{" + pairs[i] + "}", String.valueOf(pairs[i + 1]));
        }
        return out;
    }
}
