package de.varo.offline;

import de.varo.VaroPlugin;
import de.varo.data.VaroPlayer;
import de.varo.util.Txt;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.*;
import org.bukkit.inventory.EntityEquipment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.NamespacedKey;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Klassisches Varo-Feature: Loggt sich ein Spieler aus, bleibt an seiner Position
 * ein Zombie (oder Villager) mit seinem Namen stehen. Wird der getoetet, ist der
 * Spieler raus.
 */
public class OfflineEntityManager {

    private final VaroPlugin plugin;
    private final NamespacedKey key;
    /** Entity-UUID -> Spieler-UUID */
    private final Map<UUID, UUID> zuordnung = new HashMap<>();

    public OfflineEntityManager(VaroPlugin plugin) {
        this.plugin = plugin;
        this.key = new NamespacedKey(plugin, "offline_spieler");
    }

    // ================= Spawnen =================

    public void spawn(Player p) {
        if (!plugin.settings().offlineEntityAktiv()) return;
        if (p.hasPermission("varo.bypass.offlineentity")) return;

        VaroPlayer vp = plugin.data().getOrCreate(p);
        if (!vp.lebt()) return;

        // Inventar-Snapshot fuer den Fall, dass das Entity getoetet wird
        if (plugin.settings().offlineInventarDroppen()) {
            vp.offlineInventar(p.getInventory().getContents());
        }

        Location loc = p.getLocation();
        EntityType typ = plugin.settings().offlineEntityTyp();

        Entity e = loc.getWorld().spawnEntity(loc, typ);
        if (!(e instanceof LivingEntity le)) {
            e.remove();
            return;
        }

        le.customName(Txt.c("&7» &f" + p.getName() + " &8(offline)"));
        le.setCustomNameVisible(true);
        le.setPersistent(true);
        le.setRemoveWhenFarAway(false);
        le.setSilent(true);
        le.setCanPickupItems(false);
        le.setAI(false);
        le.setCollidable(true);

        if (le instanceof Ageable ageable) ageable.setAdult();
        if (le instanceof Zombie zombie) {
            zombie.setShouldBurnInDay(false);
            zombie.setAdult();
        }

        var maxHp = le.getAttribute(Attribute.MAX_HEALTH);
        if (maxHp != null) {
            maxHp.setBaseValue(20.0);
            le.setHealth(20.0);
        }

        if (plugin.settings().offlineAusruestung()) {
            kopiereAusruestung(p, le);
        }

        le.getPersistentDataContainer().set(key, PersistentDataType.STRING, p.getUniqueId().toString());

        zuordnung.put(le.getUniqueId(), p.getUniqueId());
        vp.offlineEntity(le.getUniqueId());
        plugin.data().speichern();
    }

    private void kopiereAusruestung(Player p, LivingEntity le) {
        EntityEquipment eq = le.getEquipment();
        if (eq == null) return;
        var inv = p.getInventory();
        eq.setHelmet(kopie(inv.getHelmet()));
        eq.setChestplate(kopie(inv.getChestplate()));
        eq.setLeggings(kopie(inv.getLeggings()));
        eq.setBoots(kopie(inv.getBoots()));
        eq.setItemInMainHand(kopie(inv.getItemInMainHand()));
        eq.setHelmetDropChance(0f);
        eq.setChestplateDropChance(0f);
        eq.setLeggingsDropChance(0f);
        eq.setBootsDropChance(0f);
        eq.setItemInMainHandDropChance(0f);
    }

    private ItemStack kopie(ItemStack i) {
        return i == null ? null : i.clone();
    }

    // ================= Entfernen =================

    public void entferne(Player p) {
        VaroPlayer vp = plugin.data().get(p.getUniqueId());
        if (vp == null || vp.offlineEntity() == null) return;
        entferneEntity(vp.offlineEntity());
        zuordnung.remove(vp.offlineEntity());
        vp.offlineEntity(null);
        vp.offlineInventar(null);
        plugin.data().speichern();
    }

    private void entferneEntity(UUID entityId) {
        Entity e = Bukkit.getEntity(entityId);
        if (e != null) {
            e.remove();
            return;
        }
        // Fallback: Chunks durchsuchen (falls Entity in ungeladenem Chunk liegt)
        for (World w : Bukkit.getWorlds()) {
            for (Entity ent : w.getEntities()) {
                if (ent.getUniqueId().equals(entityId)) {
                    ent.remove();
                    return;
                }
            }
        }
    }

    /** Gibt die Spieler-UUID zurueck, falls das Entity ein Offline-Entity ist. */
    public UUID spielerVon(Entity e) {
        String s = e.getPersistentDataContainer().get(key, PersistentDataType.STRING);
        if (s != null) {
            try { return UUID.fromString(s); } catch (IllegalArgumentException ignored) {}
        }
        return zuordnung.get(e.getUniqueId());
    }

    public boolean istOfflineEntity(Entity e) {
        return spielerVon(e) != null;
    }

    /** Beim Serverstart: Zuordnung aus den Spielerdaten wiederherstellen. */
    public void wiederherstellen() {
        zuordnung.clear();
        for (VaroPlayer vp : plugin.data().alle()) {
            if (vp.offlineEntity() != null) {
                zuordnung.put(vp.offlineEntity(), vp.uuid());
            }
        }
    }

    /** Entfernt das Offline-Entity eines bestimmten Spielers (z.B. beim Ausscheiden). */
    public void alleEntfernenFuer(de.varo.data.VaroPlayer vp) {
        if (vp == null || vp.offlineEntity() == null) return;
        entferneEntity(vp.offlineEntity());
        zuordnung.remove(vp.offlineEntity());
        vp.offlineEntity(null);
    }

    /** Alle Offline-Entities entfernen (z.B. vor einem Welt-Reset oder per Befehl). */
    public void alleEntfernen() {
        for (VaroPlayer vp : plugin.data().alle()) {
            if (vp.offlineEntity() != null) {
                entferneEntity(vp.offlineEntity());
                vp.offlineEntity(null);
            }
        }
        zuordnung.clear();
        plugin.data().speichern();
    }
}
