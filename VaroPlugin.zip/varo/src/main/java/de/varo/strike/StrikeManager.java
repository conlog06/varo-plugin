package de.varo.strike;

import de.varo.VaroPlugin;
import de.varo.data.VaroPlayer;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

public class StrikeManager {

    private final VaroPlugin plugin;

    public StrikeManager(VaroPlugin plugin) {
        this.plugin = plugin;
    }

    /** Gibt true zurueck, wenn der Spieler durch diesen Strike ausgeschieden ist. */
    public boolean strikeGeben(VaroPlayer vp, String grund, String vonWem) {
        if (!plugin.settings().strikesAktiv()) return false;

        vp.strikes(vp.strikes() + 1);
        vp.strikeGruende().add(grund + " (von " + vonWem + ")");
        plugin.data().speichern();

        int max = plugin.settings().strikeMaximum();

        Bukkit.broadcast(plugin.messages().chat("strike-broadcast",
                "spieler", vp.name(), "anzahl", vp.strikes(), "max", max, "grund", grund));

        Player online = Bukkit.getPlayer(vp.uuid());
        if (online != null) {
            online.sendMessage(plugin.messages().chat("strike-erhalten",
                    "grund", grund, "anzahl", vp.strikes(), "max", max));
        }

        if (plugin.settings().discordAktiv() && plugin.settings().discordBeiStrike()) {
            plugin.discord().sende("⚠ **" + vp.name() + "** hat einen Strike erhalten ("
                    + vp.strikes() + "/" + max + ") — " + grund);
        }

        if (vp.strikes() >= max) {
            Bukkit.broadcast(plugin.messages().chat("strike-maximum", "spieler", vp.name()));
            plugin.deathManager().spielerAusscheiden(vp, "Strike-Limit erreicht");
            return true;
        }
        return false;
    }

    public boolean strikeEntfernen(VaroPlayer vp) {
        if (vp.strikes() <= 0) return false;
        vp.strikes(vp.strikes() - 1);
        if (!vp.strikeGruende().isEmpty()) {
            vp.strikeGruende().remove(vp.strikeGruende().size() - 1);
        }
        plugin.data().speichern();
        return true;
    }
}
