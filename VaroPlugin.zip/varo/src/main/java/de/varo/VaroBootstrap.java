package de.varo;

import io.papermc.paper.plugin.bootstrap.BootstrapContext;
import io.papermc.paper.plugin.bootstrap.PluginBootstrap;

import java.io.*;
import java.nio.file.*;
import java.util.Comparator;
import java.util.Properties;
import java.util.Random;
import net.kyori.adventure.text.logger.slf4j.ComponentLogger;

/**
 * Laeuft VOR dem Laden der Welten. Genau deshalb existiert diese Klasse:
 * Welt-Ordner koennen nicht geloescht werden, solange der Server sie geladen hat.
 *
 * Ablauf beim Welt-Reset:
 *   1. DeathManager sichert die Welten und schreibt "regenerate.flag", dann Shutdown.
 *   2. Beim naechsten Start findet dieser Bootstrapper das Flag, loescht die Welt-Ordner
 *      und traegt einen neuen Seed in die server.properties ein.
 *   3. Der Server erzeugt die Welten anschliessend von selbst neu.
 */
public class VaroBootstrap implements PluginBootstrap {

    public static final String FLAG_DATEI = "regenerate.flag";

    @Override
    public void bootstrap(BootstrapContext context) {
        ComponentLogger log = context.getLogger();
        Path datenOrdner = context.getDataDirectory();          // <server>/plugins/VaroPlugin
        Path flagge = datenOrdner.resolve(FLAG_DATEI);

        if (!Files.exists(flagge)) return;

        Path serverRoot = datenOrdner.getParent().getParent();  // <server>
        log.info("[Varo] Regenerations-Flag gefunden - Welten werden neu erstellt.");

        try {
            Properties flagInhalt = new Properties();
            try (Reader r = Files.newBufferedReader(flagge)) {
                flagInhalt.load(r);
            }

            String weltenListe = flagInhalt.getProperty("welten", "world,world_nether,world_the_end");
            for (String welt : weltenListe.split(",")) {
                String name = welt.trim();
                if (name.isEmpty()) continue;
                Path ordner = serverRoot.resolve(name);
                if (Files.exists(ordner)) {
                    loescheRekursiv(ordner);
                    log.info("[Varo] Welt geloescht: " + name);
                }
            }

            String seed = flagInhalt.getProperty("seed", "");
            if (seed.isBlank()) seed = String.valueOf(new Random().nextLong());
            setzeSeed(serverRoot.resolve("server.properties"), seed, log);

            Files.deleteIfExists(flagge);
            log.info("[Varo] Regeneration abgeschlossen. Neuer Seed: " + seed);

        } catch (Exception e) {
            log.error("[Varo] Regeneration fehlgeschlagen: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private void loescheRekursiv(Path wurzel) throws IOException {
        try (var stream = Files.walk(wurzel)) {
            stream.sorted(Comparator.reverseOrder()).forEach(p -> {
                try { Files.deleteIfExists(p); } catch (IOException ignored) {}
            });
        }
    }

    private void setzeSeed(Path props, String seed, ComponentLogger log) {
        if (!Files.exists(props)) {
            log.warn("[Varo] server.properties nicht gefunden - Seed nicht gesetzt.");
            return;
        }
        try {
            var zeilen = Files.readAllLines(props);
            boolean gefunden = false;
            for (int i = 0; i < zeilen.size(); i++) {
                if (zeilen.get(i).startsWith("level-seed=")) {
                    zeilen.set(i, "level-seed=" + seed);
                    gefunden = true;
                    break;
                }
            }
            if (!gefunden) zeilen.add("level-seed=" + seed);
            Files.write(props, zeilen);
        } catch (IOException e) {
            log.warn("[Varo] server.properties konnte nicht geschrieben werden: " + e.getMessage());
        }
    }
}
