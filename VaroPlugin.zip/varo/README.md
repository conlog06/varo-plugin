# VaroPlugin

Varo-artiges Projekt-Plugin für Paper 26.2 („Chaos Cubed"). Ausgelegt auf kleine Runden (5 Spieler), Zeitzone **Europe/Berlin**, komplett ohne MySQL — alle Daten liegen als YAML im Plugin-Ordner.

---

## Bauen

**Mit Maven** (Standard):

```bash
mvn clean package
```

Das JAR liegt danach unter `target/VaroPlugin-1.0.0.jar` und kommt in den `plugins/`-Ordner.

Voraussetzung ist JDK 25 — Paper 26.2 verlangt das. Falls `mvn -v` eine ältere Java-Version zeigt, `JAVA_HOME` auf die JDK-25-Installation setzen.

**Mit Gradle** (Alternative, in `alternativ-gradle/`): Beide Dateien ins Projektwurzelverzeichnis verschieben und die `pom.xml` umbenennen. Braucht **Gradle 8.14 oder neuer** — ältere Versionen kennen die Java-25-Toolchain nicht. Das Shadow-Plugin ist bewusst raus: es gibt keine Abhängigkeiten zu shaden, und Shadow 9 verlangt seinerseits Gradle 8.11+.

> Wenn VS Code das Projekt als Gradle-Projekt importiert und dabei scheitert, liegt es an der mitgelieferten Gradle-Version der Java-Erweiterung. Deshalb liegen die Gradle-Dateien in einem Unterordner — so greift der Maven-Import.

---

## Befehle registrieren — kein `commands:` in der YAML

Paper-Plugins mit `paper-plugin.yml` unterstützen **keine** YAML-Befehlsdeklarationen. `JavaPlugin#getCommand()` wirft dort eine `UnsupportedOperationException`. Die Registrierung passiert deshalb im Code:

```java
registerCommand("varo", "Beschreibung", List.of("v"), new VaroBasicCommand("varo", handler));
```

`VaroBasicCommand` implementiert Papers `BasicCommand` und reicht an `VaroCommand` durch. Rechte (`permissions:`) funktionieren weiterhin ganz normal über die `paper-plugin.yml`.

---

## Was drin ist

| Feature | Umsetzung |
|---|---|
| Scoreboard / Tablist / Actionbar / Nametags | Pro Spieler eigenes Scoreboard, Sidebar über Team-Präfixe (flackerfrei) |
| **Admin-GUI** | `/varo menu` — alle Einstellungen per Klick, ohne Reload |
| Session-System | 3 Joins/Tag, 60 min pro Session, optionale Pause, Chatwarnungen + Titel-Countdown |
| **Server-Öffnungszeiten** | 06:00–23:59 Berlin, Vorwarnungen, Kick bei Schluss, Login-Sperre davor |
| Projekttag | Tageszähler ab Startdatum, Tageswechsel-Stunde frei wählbar |
| **Inaktivitäts-Strike** | Wer einen Tag gar nicht online war, bekommt automatisch einen Strike |
| Strikes | Limit 5, bei Erreichen scheidet der Spieler aus; im GUI zurücknehmbar |
| **Herzverlust pro Tod** | −0,5 ♥ dauerhaft, Betrag im GUI einstellbar; bei 0 ♥ ist Schluss |
| **PvP-Schalter** | Standard aus, optional automatische Freischaltung ab Tag X |
| Combat-Tag | 15 s nach jedem Treffer, Logout = Tod (nur relevant wenn PvP an) |
| Auto-Setup | Schwierigkeit, Weltgrenze, Gamerules, Spawnschutz beim Start |
| Backups | ZIP per `java.util.zip`, automatisch + manuell + vor jedem Reset |
| Rucksack | Virtuelles Inventar pro Spieler, im Kampf gesperrt |
| Teamkiste | Geteiltes Inventar pro Team, mehrere Zuschauer gleichzeitig |
| Offline-Entity | Zombie/Villager mit Spielernamen + Rüstung; Tod = Tod des Spielers |
| Discord | Webhook bei Tod, Strike, **Strafe/Herzverlust**, Welt-Reset, optional Serverzeiten |
| Welt-Reset bei Tod | Backup → Countdown → Shutdown → neue Welten beim Neustart |

---

## Das Admin-GUI

`/varo menu` (auch `/varo gui` oder `/varo admin`). Alles wird direkt in die `config.yml` geschrieben und wirkt sofort.

**Bedienung bei Zahlenwerten:** Linksklick +, Shift-Linksklick ++, Rechtsklick −, Shift-Rechtsklick −−. Bei Herzen sind die Schritte 0,5 und 2.

| Untermenü | Einstellbar |
|---|---|
| Projekt (oben) | Läuft / Pausiert umschalten |
| Sessions | Joins pro Tag, Dauer, Pause, Actionbar |
| Öffnungszeiten | An/Aus, Öffnungs- und Schlusszeit auf die Minute |
| Strikes | An/Aus, Maximum, Inaktivitätsregel, ab welchem Tag sie greift |
| Tod & Herzen | Modus, Herzverlust pro Tod, Start-Herzen, Aus-Schwelle, Welt-Reset, Countdown |
| PvP | An/Aus, automatisch ab Tag X, Kampf-Tag-Dauer |
| Discord | Alle Meldungstypen einzeln, Testnachricht senden |
| Backups | Automatik, Intervall, Aufbewahrung, sofortiges Backup |
| Spielerverwaltung | Pro Spieler: Strike geben/zurücknehmen, Herzen ±, Joins zurücksetzen, Ausscheiden/Wiederbeleben, Strike-Verlauf |

Die Webhook-URL bleibt bewusst nur in der `config.yml` — die gehört nicht in ein Inventar, wo jeder mit F3+I mitlesen könnte.

---

## Strikes

Fünf Strikes, dann ist man raus. Es gibt zwei Wege dahin:

- **Manuell**, per `/varo strike <spieler> <grund>` oder im GUI
- **Automatisch bei Inaktivität** — beim Tageswechsel prüft das Plugin, wer am Vortag gar nicht online war. Greift erst ab Projekttag 2 (einstellbar), damit der Starttag niemanden bestraft.

Zurücknehmen geht über `/varo unstrike <spieler>` oder im GUI mit einem Klick. Jede Vergabe *und* jede Rücknahme landet im Discord.

---

## Tod, Herzen und Welt-Reset

Ein Tod bedeutet jetzt zweierlei — das musste ich auflösen, weil sich deine beiden Vorgaben widersprechen. Umgesetzt als Modus:

**`HERZVERLUST` (Standard):** Wer stirbt, verliert dauerhaft 0,5 ♥ Maximalleben. Bei ≤ 0,5 ♥ ist der Spieler komplett raus. Die Herzen überleben einen Welt-Reset (`tod.herzen-behalten: true`) — sonst wäre die Strafe nach dem ersten Reset weg.

**`AUSSCHEIDEN`:** Wie ursprünglich besprochen — ein Tod, und der Spieler ist raus.

Der Welt-Reset läuft in **beiden** Modi, solange `tod.welt-reset: true`. Das heißt: jeder einzelne Tod kostet ein halbes Herz *und* stoppt den Server für eine neue Welt. Wenn dir das zu heftig ist, schalte den Welt-Reset im GUI ab — dann kostet Sterben nur Herzen und ihr spielt weiter.

---

## Wie der Welt-Reset funktioniert

Der interessante Teil. Ein Plugin kann Weltordner **nicht** löschen, solange der Server läuft — die Dateien sind gesperrt und die Welten sind zum Zeitpunkt von `onDisable()` noch geladen.

Gelöst über Papers **Bootstrapper** (`VaroBootstrap`), der *vor* dem Laden der Welten läuft:

1. Spieler stirbt → Broadcast, Discord, Countdown (30 s, konfigurierbar)
2. Teamkisten sichern, Offline-Entities entfernen, `world.save()` + `savePlayers()`
3. Backup als ZIP nach `varo-backups/`
4. Spielerdaten für die neue Season zurücksetzen, Season-Zähler +1, Startdatum = heute
5. `regenerate.flag` in den Plugin-Ordner schreiben (enthält Weltnamen + neuen Seed)
6. Alle kicken, `Bukkit.shutdown()`
7. **Beim nächsten Start:** Bootstrapper findet das Flag, löscht `world`, `world_nether`, `world_the_end`, trägt den neuen Seed in die `server.properties` ein und löscht das Flag
8. Der Server erzeugt die Welten von selbst neu

> **Wichtig:** Der Server muss nach dem Stopp automatisch neu starten, sonst passiert Schritt 7 nie. Ein simples Startskript reicht:
> ```bash
> while true; do java -Xmx6G -jar paper.jar nogui; sleep 5; done
> ```
> Bei Hostern wie Pterodactyl/Aternos ist Auto-Restart meist eine Checkbox.

---

## Befehle

| Befehl | Rechte | Wirkung |
|---|---|---|
| `/varo info [spieler]` | alle | Status, Joins, Strikes, Herzen, Kills, Spielzeit |
| `/varo menu` | `varo.admin` | **Admin-Setup als GUI** |
| `/rucksack` (`/rs`) | alle | Rucksack öffnen |
| `/teamkiste` (`/tk`) | alle | Teamkiste öffnen |
| `/varo set dauer <min>` | `varo.admin` | Sessiondauer **im laufenden Projekt** ändern |
| `/varo set joins <n>` | `varo.admin` | Joins pro Tag ändern |
| `/varo set pause <min>` | `varo.admin` | Abklingzeit zwischen Sessions |
| `/varo pause` / `/varo fortsetzen` | `varo.admin` | Limits aussetzen (z. B. Bauphase) |
| `/varo team erstellen <id> <FARBE> [Name]` | `varo.admin` | Team anlegen |
| `/varo team add <id> <spieler>` | `varo.admin` | Spieler zuweisen |
| `/varo team loeschen\|remove\|liste` | `varo.admin` | Teamverwaltung |
| `/varo strike <spieler> <grund>` | `varo.admin` | Strike vergeben |
| `/varo unstrike <spieler>` | `varo.admin` | Strike zurücknehmen |
| `/varo kill <spieler> [grund]` | `varo.admin` | Manuell ausscheiden lassen |
| `/varo revive <spieler>` | `varo.admin` | Wiederbeleben |
| `/varo joins <spieler> <n>` | `varo.admin` | Join-Zähler korrigieren |
| `/varo herzen <spieler> <n>` | `varo.admin` | Herzen setzen |
| `/varo tag <n>` | `varo.admin` | Projekttag setzen (verschiebt das Startdatum) |
| `/varo backup` | `varo.admin` | Backup jetzt erstellen |
| `/varo reset` | `varo.admin` | Welt-Reset manuell (2× eingeben zum Bestätigen) |
| `/varo reload` | `varo.admin` | Config + Nachrichten neu laden |

**Rechte zum Umgehen:** `varo.bypass.session`, `varo.bypass.oeffnungszeiten`, `varo.bypass.kampftag`, `varo.bypass.offlineentity`

---

## Verhaltensentscheidungen, die du kennen solltest

**Frühzeitiger Logout kostet einen Join.** Wer nach 10 Minuten rausgeht, hat trotzdem eine seiner drei Sessions verbraucht und bekommt beim nächsten Join wieder volle 60 Minuten. Alternative Interpretation wäre „Restzeit sparen" — das ist bewusst *nicht* implementiert, weil es zu Taktik-Logouts im Kampf einlädt. Falls du es anders willst: `SessionManager.starteSession()` müsste die Restzeit aus den Spielerdaten laden statt `sessionSekunden()` zu nehmen.

**PvP ist aus, der Combat-Tag bleibt drin.** Solange PvP deaktiviert ist, kann der Tag gar nicht ausgelöst werden — Spielerschaden wird vorher abgebrochen. Sobald du PvP im GUI anschaltest (oder `pvp.ab-tag` erreicht ist), greift er automatisch. Das Combat-Log-Feature schläft also, statt zu verschwinden.

**Der Inaktivitäts-Strike hängt am Tageswechsel, nicht am Kalendertag.** Wenn du `tageswechsel-stunde` auf z. B. 4 stellst, zählt „ein Tag" von 4 Uhr bis 4 Uhr. Nachtsessions bis 3 Uhr gehören damit noch zum Vortag — was mit dem Serverfenster bis 23:59 aber ohnehin nicht kollidiert.

**Serverschluss kickt auch mitten in der Session.** Wer um 23:55 joint, hat fünf Minuten, nicht sechzig. Die Session gilt trotzdem als verbraucht. Wenn du das anders willst, müsste `SessionManager.starteSession()` den Join ablehnen, sobald `sekundenBisSchluss()` kleiner als die Sessiondauer ist.

**Backups mit laufendem Server** sind Momentaufnahmen. `session.lock` wird übersprungen, einzelne gesperrte Regionsdateien lösen eine Warnung aus statt das Backup abzubrechen. Für ein perfekt konsistentes Backup müsste der Server stoppen — beim Reset-Backup ist genau das der Fall.

---

## Nicht umgesetzt und warum

**Fabric/Forge.** Ein Paper-Plugin und eine Fabric/Forge-Mod haben keine gemeinsame API — kein `plugin.yml`, keine Bukkit-Events, kein Scoreboard-API, andere Klassenlader, andere Entity-Klassen. Das wäre kein „kompatibel machen", sondern zwei bis drei separate Neuimplementierungen des kompletten Funktionsumfangs, plus ein abstrahierter Kern dazwischen. Für ein Fünf-Personen-Projekt lohnt das nicht, und Varo läuft ohnehin praktisch immer auf Paper. Falls ihr modded spielen wollt: Paper + Mods geht über Hybrid-Server (Arclight/Mohist), ist aber erfahrungsgemäß fragil.

**Discord-Bot statt Webhook.** JDA wäre ~10 MB Shaded-Dependency, Bot-Token-Verwaltung und ein Gateway-Thread für eine Funktion, die ein Webhook in 40 Zeilen erledigt. `DiscordNotifier` ist bewusst so klein, dass du ihn ersetzen kannst, falls du später Slash-Commands willst.

---

## Ungetestet

Ich konnte das Projekt hier nicht kompilieren — der Container hat keinen Zugriff auf `repo.papermc.io`. Rechne beim ersten `./gradlew build` mit ein paar Import-Korrekturen, vor allem bei Klassen, die sich zwischen Versionen bewegt haben:

- `Attribute.MAX_HEALTH` (hieß vor 1.21.3 `GENERIC_MAX_HEALTH`)
- `Criteria.DUMMY` im Scoreboard-Paket
- `org.bukkit.ChatColor` ist deprecated, funktioniert aber noch
- Material-Namen im GUI (`TOTEM_OF_UNDYING`, `SUNFLOWER`, `WRITABLE_BOOK` …)

Das sind Ein-Zeilen-Fixes, keine strukturellen Probleme.
