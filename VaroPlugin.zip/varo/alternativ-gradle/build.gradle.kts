// Alternative zu Maven. Braucht Gradle 8.14 oder neuer (wegen Java-25-Toolchain).
// Zum Benutzen: diese Datei und settings.gradle.kts ins Projektwurzelverzeichnis
// verschieben und die pom.xml loeschen oder umbenennen.
plugins {
    java
}

group = "de.varo"
version = "1.0.0"

repositories {
    mavenCentral()
    maven("https://repo.papermc.io/repository/maven-public/")
}

dependencies {
    compileOnly("io.papermc.paper:paper-api:26.2.build.+")
}

java {
    toolchain.languageVersion.set(JavaLanguageVersion.of(25))
}
